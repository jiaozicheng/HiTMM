from data.t2m_dataset import Text2MotionDatasetEval, collate_fn # TODO
from utils.word_vectorizer import WordVectorizer
import numpy as np
from os.path import join as pjoin
from torch.utils.data import Dataset, DataLoader
from utils.get_opt import get_opt
from datasets.interhuman import InterHumanDataset
import copy
from tqdm import tqdm
from models import *
from datasets.evaluator_models import InterCLIP
# from utils.utils import *
class EvaluationDataset(Dataset):

    def __init__(self,vq_model, res_model, trans, dataset, device,mm_num_samples, mm_num_repeats, time_steps,cond_scale, temperature, topkr, gsample=True, force_mask=False,
                                              cal_mm=True, res_cond_scale=2):
        self.normalizer = MotionNormalizer()
        self.vq_model = vq_model.to(device)
        self.vq_model.eval()
        self.res_model = res_model.to(device)
        self.res_model.eval()
        self.trans = trans.to(device)
        self.trans.eval()
        dataloader = DataLoader(dataset, batch_size=1,  num_workers=0, drop_last=True, shuffle=True)
        self.max_length = dataset.max_length

        self.time_steps = time_steps

        self.cond_scale = cond_scale

        self.temperature = temperature

        self.topkr = topkr

        self.gsample = gsample

        self.force_mask = force_mask

        self.cal_mm = cal_mm

        self.res_cond_scale = res_cond_scale

        self.mm_num_samples = mm_num_samples

        self.mm_num_repeats = mm_num_repeats

        mean = np.load('/opt/data/private/myfile/momask_two/dataset/intergentwoperson/global_mean.npy')
        std = np.load('/opt/data/private/myfile/momask_two/dataset/intergentwoperson/global_std.npy')
        idxs = list(range(len(dataset)))
        random.shuffle(idxs)
        mm_idxs = idxs[:mm_num_samples]

        generated_motions = []
        mm_generated_motions = []
        # Pre-process all target captions
        with torch.no_grad():
            for i, data in tqdm(enumerate(dataloader)):
                name, text, motion1, motion2, motion_lens = data
                motion_lens = motion_lens.cuda()
                batch = {}
                if i in mm_idxs:
                    # batch["text"] = list(text) * mm_num_repeats
                    motion_multimodality_batch = []
                    for _ in range(self.mm_num_repeats):
                        mids = self.trans.generate(text, (motion_lens//4)*2, self.time_steps, self.cond_scale,
                                              temperature=1)
                        pred_ids = self.res_model.generate(mids, text, (motion_lens // 4) * 2,
                                                  temperature=1, cond_scale=2)
                        pred_ids1 = pred_ids[:, 0::2, :]  # 提取奇数列
                        pred_ids2 = pred_ids[:, 1::2, :]

                        pred_motion1 = self.vq_model.forward_decoder(pred_ids1)
                        pred_motion2 = self.vq_model.forward_decoder(pred_ids2)
                        pred_motions = torch.cat([pred_motion1, pred_motion2], dim=-1)
                        motion_multimodality_batch.append(pred_motions)
                    motions_output = torch.cat(motion_multimodality_batch, dim=0)  # (30, motionlens, 524)
                else:
                    motion_multimodality_batch = []
                    mids = self.trans.generate(text, (motion_lens // 4) * 2, self.time_steps, self.cond_scale,
                                               temperature=1)
                    pred_ids = self.res_model.generate(mids, text, (motion_lens // 4) * 2,
                                                       temperature=1, cond_scale=2)
                    pred_ids1 = pred_ids[:, 0::2, :]  # 提取奇数列
                    pred_ids2 = pred_ids[:, 1::2, :]

                    pred_motion1 = self.vq_model.forward_decoder(pred_ids1)
                    pred_motion2 = self.vq_model.forward_decoder(pred_ids2)
                    pred_motions = torch.cat([pred_motion1, pred_motion2], dim=-1)
                    motion_multimodality_batch.append(pred_motions)
                    motions_output = torch.cat(motion_multimodality_batch, dim=0)  # (30, motionlens, 524)
                batch["motion_lens"] = (motion_lens//4)*4





                # motionpred1 = pred_motions[:, :, :262]
                # motionpred2 = pred_motions[:, :, 262:524]
                # motionpred1 = motionpred1.cpu()
                # motionpred2 = motionpred2.cpu()
                # motionpred1 = motionpred1.numpy()
                # motionpred2 = motionpred2.numpy()
                # motionpred1 = (motionpred1 * std) + mean
                # motionpred2 = (motionpred2 * std) + mean
                # motionpred1 = torch.from_numpy(motionpred1).float()
                # motionpred2 = torch.from_numpy(motionpred2).float()
                # motions_output=torch.cat([motionpred1, motionpred2], dim=-1)
                motions_output = motions_output.reshape(motions_output.shape[0], motions_output.shape[1], 2, -1)
                # motions_output = self.normalizer.backward(motions_output.cpu().detach().numpy())
                motions_output = motions_output.cpu().detach().numpy() * std + mean



                # motions_output = motions_output.reshape(motions_output.shape[0], motions_output.shape[1], 2, -1)
                # motions_output[..., :22 * 3] = filters.gaussian_filter1d(motions_output[..., :22 * 3], 1, axis=0, mode='nearest')
                # motions_output[..., 22 * 3:22 * 6] = filters.gaussian_filter1d(motions_output[..., 22 * 3:22 * 6], 0.1, axis=0, mode='nearest')
                # motions_output[..., 22 * 6:22 * 6 + 21 * 6] = filters.gaussian_filter1d(motions_output[..., 22 * 6:22 * 6 + 21 * 6], 0.5, axis=0, mode='nearest')

                B,T = motions_output.shape[0], motions_output.shape[1]
                if T < self.max_length:
                    padding_len = self.max_length - T
                    D = motions_output.shape[-1]
                    padding_zeros = np.zeros((B, padding_len, 2, D))
                    motions_output = np.concatenate((motions_output, padding_zeros), axis=1)
                assert motions_output.shape[1] == self.max_length


                sub_dict = {'motion1': motions_output[0, :,0],
                            'motion2': motions_output[0, :,1],
                            'motion_lens': motion_lens[0],
                            'text': text[0]}
                generated_motions.append(sub_dict)
                if i in mm_idxs:
                    mm_sub_dict = {'mm_motions': motions_output,
                                   'motion_lens': motion_lens[0],
                                    'text': text[0]}
                    mm_generated_motions.append(mm_sub_dict)


        self.generated_motions = generated_motions
        self.mm_generated_motions = mm_generated_motions

    def __len__(self):
        return len(self.generated_motions)

    def __getitem__(self, item):
        data = self.generated_motions[item]
        motion1, motion2, motion_lens, text = data['motion1'], data['motion2'], data['motion_lens'], data['text']
        return "generated", text, motion1, motion2, motion_lens


class MMGeneratedDataset(Dataset):
    def __init__(self, motion_dataset):
        self.dataset = motion_dataset.mm_generated_motions

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, item):
        data = self.dataset[item]
        mm_motions = data['mm_motions']
        motion_lens = data['motion_lens']
        mm_motions1 = mm_motions[:,:,0]
        mm_motions2 = mm_motions[:,:,1]
        text = data['text']
        motion_lens = motion_lens.cpu().numpy()
        motion_lens = np.array([motion_lens]*mm_motions1.shape[0])
        return "mm_generated", text, mm_motions1, mm_motions2, motion_lens
# def get_dataset_motion_loader1(opt,mean,std, batch_size):
#     opt = copy.deepcopy(opt)
#     # Configurations of T2M dataset and KIT dataset is almost the same
#     if opt.NAME == 'interhuman':
#         print('Loading dataset %s ...' % opt.NAME)
#
#         dataset = InterHumanDataset(opt,mean,std)
#         dataloader = DataLoader(dataset, batch_size=batch_size, drop_last=True, num_workers=4,
#                               shuffle=True, pin_memory=True)
#     else:
#         raise KeyError('Dataset not Recognized !!')
#
#     print('Ground Truth Dataset Loading Completed!!!')
#     return dataloader, dataset
def get_dataset_motion_loader(opt,mean,std, batch_size):
    opt = copy.deepcopy(opt)
    # Configurations of T2M dataset and KIT dataset is almost the same
    if opt.NAME == 'interhuman':
        print('Loading dataset %s ...' % opt.NAME)

        dataset = InterHumanDataset(opt,mean,std)
        dataloader = DataLoader(dataset, batch_size=batch_size, num_workers=0, drop_last=True, shuffle=True)
    else:
        raise KeyError('Dataset not Recognized !!')

    print('Ground Truth Dataset Loading Completed!!!')
    return dataloader, dataset
def get_motion_loader(batch_size, vq_model, res_model, trans, ground_truth_dataset, device,mm_num_samples, mm_num_repeats, time_steps, cond_scale, temperature, topkr,force_mask,
                                              cal_mm):
    # Currently the configurations of two datasets are almost the same
    dataset = EvaluationDataset(vq_model, res_model, trans, ground_truth_dataset, device,mm_num_samples, mm_num_repeats,time_steps, cond_scale, temperature, topkr, force_mask=force_mask,
                                              cal_mm=cal_mm)
    mm_dataset = MMGeneratedDataset(dataset)

    motion_loader = DataLoader(dataset, batch_size=batch_size, drop_last=True, num_workers=0, shuffle=True)
    mm_motion_loader = DataLoader(mm_dataset, batch_size=1, num_workers=0)

    print('Generated Dataset Loading Completed!!!')

    return motion_loader, mm_motion_loader

