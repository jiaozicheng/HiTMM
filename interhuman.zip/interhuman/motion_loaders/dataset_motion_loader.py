# from data.t2m_dataset import * # TODO
from utils.word_vectorizer import WordVectorizer
import numpy as np
from os.path import join as pjoin
from torch.utils.data import Dataset, DataLoader
from utils.get_opt import get_opt
from datasets.interhuman import *
import copy
from tqdm import tqdm
from models import *
from datasets.evaluator_models import InterCLIP
from torch.utils.data._utils.collate import default_collate
from torch.utils.data.distributed import DistributedSampler
# from utils.utils import *
class EvaluationDataset(Dataset):

    def __init__(self, vq_model,t2m_transformer,res_model, dataset, device, mm_num_samples, mm_num_repeats,mean,std,time_steps,cond_scale,temperature,topkr,force_mask,gsample=True,res_cond_scale=4):

        self.vq_model = vq_model.to(device)
        self.t2m_transformer = t2m_transformer.to(device)
        self.res_model = res_model.to(device)
        dataloader = DataLoader(dataset, batch_size=1, num_workers=0, shuffle=True)
        self.max_length = dataset.max_length

        idxs = list(range(len(dataset)))
        random.shuffle(idxs)
        mm_idxs = idxs[:mm_num_samples]

        generated_motions = []
        mm_generated_motions = []

        total_time = 0
        inference_count = 0
        max_inferences = 10

        # Pre-process all target captions
        with torch.no_grad():
            for i, data in tqdm(enumerate(dataloader)):
                name, text, motion1, motion2, motion_lens = data
                motion_lens = motion_lens.cuda()
                batch = {}
                if i in mm_idxs:
                    motions_output = []
                    for _ in range(mm_num_repeats):

                        mids = self.t2m_transformer.generate(text, (motion_lens // 4)*2, time_steps, cond_scale, temperature=temperature,
                                              topk_filter_thres=topkr,
                                              gsample=gsample, force_mask=force_mask)

                        mids = self.res_model.generate(mids, text, (motion_lens // 4) *2,
                                                  temperature=temperature, cond_scale=res_cond_scale)

                        bs, seq, l = mids.shape[0], mids.shape[1], mids.shape[2]

                        mids1 = mids[:, 0::2, :]
                        mids2 = mids[:, 1::2, :]



                        motionpred1 = self.vq_model.forward_decoder(mids1)
                        motionpred2 = self.vq_model.forward_decoder(mids2)
                        motionpred1 = motionpred1.cpu()
                        motionpred2 = motionpred2.cpu()
                        motionpred1 = motionpred1.numpy()
                        motionpred2 = motionpred2.numpy()
                        motionpred1 = (motionpred1 * std) + mean
                        motionpred2 = (motionpred2 * std) + mean
                        motionpred1 = torch.from_numpy(motionpred1).float()
                        motionpred2 = torch.from_numpy(motionpred2).float()
                        pred_motions = torch.cat([motionpred1, motionpred2], dim=-1)
                        # em_pred = em_pred.unsqueeze(1)  #(bs, 1, d)
                        motions_output.append(pred_motions)

                    motions_output = torch.cat(motions_output, dim=0)
                else:

                    mids = self.t2m_transformer.generate(text, (motion_lens // 4) *2 , time_steps, cond_scale,
                                                         temperature=temperature,
                                                         topk_filter_thres=topkr,
                                                         gsample=gsample, force_mask=force_mask)

                    mids = self.res_model.generate(mids, text, (motion_lens // 4) *2,
                                                   temperature=temperature, cond_scale=res_cond_scale)

                    bs, seq, l = mids.shape[0], mids.shape[1], mids.shape[2]

                    mids1 = mids[:, 0::2, :]
                    mids2 = mids[:, 1::2, :]


                    motionpred1 = self.vq_model.forward_decoder(mids1)
                    motionpred2 = self.vq_model.forward_decoder(mids2)
                    motionpred1 = motionpred1.cpu()
                    motionpred2 = motionpred2.cpu()
                    motionpred1 = motionpred1.numpy()
                    motionpred2 = motionpred2.numpy()
                    motionpred1 = (motionpred1 * std) + mean
                    motionpred2 = (motionpred2 * std) + mean

                    motionpred1 = torch.from_numpy(motionpred1).float()
                    motionpred2 = torch.from_numpy(motionpred2).float()
                    motions_output = torch.cat([motionpred1, motionpred2], dim=-1)
                motions_output = motions_output.reshape(motions_output.shape[0], motions_output.shape[1], 2, -1)
                # motions_output = self.normalizer.backward(motions_output.cpu().detach().numpy())

                # motions_output[..., :22 * 3] = filters.gaussian_filter1d(motions_output[..., :22 * 3], 1, axis=0, mode='nearest')
                # motions_output[..., 22 * 3:22 * 6] = filters.gaussian_filter1d(motions_output[..., 22 * 3:22 * 6], 0.1, axis=0, mode='nearest')
                # motions_output[..., 22 * 6:22 * 6 + 21 * 6] = filters.gaussian_filter1d(motions_output[..., 22 * 6:22 * 6 + 21 * 6], 0.5, axis=0, mode='nearest')

                B,T = motions_output.shape[0], motions_output.shape[1]
                if T < self.max_length:
                    padding_len = self.max_length - T
                    D = motions_output.shape[-1]
                    padding_zeros = np.zeros((B, padding_len, 2, D))
                    motions_output = np.concatenate((motions_output, padding_zeros), axis=1)

                assert motions_output.shape[1] == self.max_length


                sub_dict = {'motion1': motions_output[0, :,0],
                            'motion2': motions_output[0, :,1],
                            'motion_lens': (motion_lens[0]//4)*4,
                            'text': text[0],
                            }
                generated_motions.append(sub_dict)
                if i in mm_idxs:
                    mm_sub_dict = {'mm_motions': motions_output,
                                   'motion_lens': (motion_lens[0]//4)*4,
                                   'text': text[0],
                                   }
                    mm_generated_motions.append(mm_sub_dict)

        # avg_time = total_time / max_inferences if max_inferences > 0 else 0
        # print(f"Average inference time over {max_inferences} effective samples: {avg_time:.4f} seconds")
        self.generated_motions = generated_motions
        self.mm_generated_motions = mm_generated_motions

    def __len__(self):
        return len(self.generated_motions)

    def __getitem__(self, item):
        data = self.generated_motions[item]
        motion1, motion2, motion_lens, text= data['motion1'], data['motion2'], data['motion_lens'], data['text']
        return "generated", text, motion1, motion2, motion_lens
class MMGeneratedDataset(Dataset):
    def __init__(self, motion_dataset):
        self.dataset = motion_dataset.mm_generated_motions

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, item):
        data = self.dataset[item]
        mm_motions = data['mm_motions']
        motion_lens = data['motion_lens']
        mm_motions1 = mm_motions[:,:,0]
        mm_motions2 = mm_motions[:,:,1]
        text = data['text']
        motion_lens = np.array([motion_lens.cpu()]*mm_motions1.shape[0])
        return "mm_generated", text, mm_motions1, mm_motions2, motion_lens
# def collate_fn(batch):
#     batch.sort(key=lambda x: x[0], reverse=True)
#     return default_collate(batch)
def cycle(iterable):
    while True:
        for x in iterable:
            yield x

def get_dataset_motion_loader_GR(opt, batch_size):
    opt = copy.deepcopy(opt)
    # Configurations of T2M dataset and KIT dataset is almost the same
    if opt.name == 'interhuman':
        print('Loading dataset %s ...' % opt.name)

        dataset = InterHumanDataset_test(opt,nor=False)
        dataloader = DataLoader(dataset, batch_size=batch_size, num_workers=0, drop_last=True, shuffle=True)

    else:
        raise KeyError('Dataset not Recognized !!')

    print('Ground Truth Dataset Loading Completed!!!')
    return dataloader, dataset



def get_dataset_motion_loader_t2m(opt, batch_size):
    opt = copy.deepcopy(opt)
    # Configurations of T2M dataset and KIT dataset is almost the same
    if opt.NAME == 'interhuman':
        print('Loading dataset %s ...' % opt.NAME)

        dataset = InterHumanDataset(opt,nor=True)
        dataloader = DataLoader(dataset, batch_size=batch_size, num_workers=4, drop_last=True, shuffle=True, pin_memory=True)
    else:
        raise KeyError('Dataset not Recognized !!')

    print('Ground Truth Dataset Loading Completed!!!')
    return dataloader, dataset

def get_dataset_motion_loader_t2m_eval(opt, batch_size):
    opt = copy.deepcopy(opt)
    # Configurations of T2M dataset and KIT dataset is almost the same
    if opt.NAME == 'interhuman':
        print('Loading dataset %s ...' % opt.NAME)

        dataset = InterHumanDataset(opt,nor=True)
        dataloader = DataLoader(dataset, batch_size=batch_size, num_workers=4, drop_last=True, shuffle=False, pin_memory=True)
    else:
        raise KeyError('Dataset not Recognized !!')

    print('Ground Truth Dataset Loading Completed!!!')
    return dataloader, dataset



def get_motion_loader(batch_size, vq_model,t2m_transformer,res_model, ground_truth_dataset, device, mm_num_samples, mm_num_repeats,mean,std,time_steps,cond_scale,temperature,topkr,force_mask,res_cond_scale):
    # Currently the configurations of two datasets are almost the same
    dataset = EvaluationDataset(vq_model,t2m_transformer,res_model, ground_truth_dataset, device, mm_num_samples=mm_num_samples, mm_num_repeats=mm_num_repeats,mean=mean,std=std,time_steps=time_steps,cond_scale=cond_scale,temperature=temperature,topkr=topkr,force_mask=force_mask,gsample=True,res_cond_scale=res_cond_scale)
    mm_dataset = MMGeneratedDataset(dataset)

    motion_loader = DataLoader(dataset, batch_size=batch_size, drop_last=True, num_workers=0, shuffle=True)
    mm_motion_loader = DataLoader(mm_dataset, batch_size=1, num_workers=0)

    print('Generated Dataset Loading Completed!!!')

    return motion_loader, mm_motion_loader

