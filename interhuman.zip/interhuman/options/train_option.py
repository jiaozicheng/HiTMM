from options.base_option import BaseOptions
import argparse

class TrainT2MOptions(BaseOptions):
    def initialize(self):
        BaseOptions.initialize(self)
        self.parser.add_argument('--batch_size', type=int, default=52, help='Batch size')
        self.parser.add_argument('--max_epoch', type=int, default=500, help='Maximum number of epoch for training')
        # self.parser.add_argument('--max_iters', type=int, default=150_000, help='Training iterations')
        #batch128 epoch600 totaliters:52800
        '''LR scheduler'''
        self.parser.add_argument('--lr', type=float, default=2e-4, help='Learning rate')
        self.parser.add_argument('--gamma', type=float, default=0.1, help='Learning rate schedule factor')
        self.parser.add_argument('--milestones', default=[40000], nargs="+", type=int,
                                 help="learning rate schedule (iterations)")
        self.parser.add_argument('--warm_up_iter', default=25000, type=int, help='number of total iterations for warmup')

        '''Condition'''
        self.parser.add_argument('--cond_drop_prob', type=float, default=0.1,
                                 help='Drop ratio of condition, for classifier-free guidance')
        self.parser.add_argument("--seed", default=3407, type=int, help="Seed")

        self.parser.add_argument('--is_continue', action="store_true", help='Is this trial continuing previous state?')
        self.parser.add_argument('--gumbel_sample', action="store_true",
                                 help='Strategy for token sampling, True: Gumbel sampling, False: Categorical sampling')
        self.parser.add_argument('--share_weight', action="store_true",
                                 help='Whether to share weight for projection/embedding, for residual transformer.')

        self.parser.add_argument('--log_every', type=int, default=50,
                                 help='Frequency of printing training progress, (iteration)')
        # self.parser.add_argument('--save_every_e', type=int, default=100, help='Frequency of printing training progress')
        self.parser.add_argument('--eval_every_e', type=int, default=10,
                                 help='Frequency of animating eval results, (epoch)')
        self.parser.add_argument('--save_latest', type=int, default=500,
                                 help='Frequency of saving checkpoint, (iteration)')
        self.parser.add_argument('--trans', type=str, default='t2mgpt', help='Transfomer Implementation')

        # self.parser.add_argument("--nb_code", type=int, default=512, help="nb of embedding")
        # self.parser.add_argument("--embed-dim-gpt", type=int, default=1024, help="embedding dimension")
        # self.parser.add_argument("--clip-dim", type=int, default=768, help="latent dimension in the clip feature")
        # self.parser.add_argument("--block-size", type=int, default=152, help="seq len")
        # self.parser.add_argument("--num-layers", type=int, default=9, help="nb of transformer layers")
        # self.parser.add_argument("--n-head-gpt", type=int, default=16, help="nb of heads")
        # self.parser.add_argument("--ff-rate", type=int, default=4, help="feedforward size")
        # self.parser.add_argument("--drop-out-rate", type=float, default=0.1, help="dropout ratio in the pos encoding")

        self.is_train = True

class Train_AUGR_Options(BaseOptions):
    def initialize(self):
        BaseOptions.initialize(self)
        self.parser.add_argument('--batch_size', type=int, default=64, help='Batch size')
        self.parser.add_argument('--max_epoch', type=int, default=1000, help='Maximum number of epoch for training')
        # self.parser.add_argument('--max_iters', type=int, default=150_000, help='Training iterations')

        '''LR scheduler'''
        self.parser.add_argument('--lr', type=float, default=2e-4, help='Learning rate')
        self.parser.add_argument('--gamma', type=float, default=0.05, help='Learning rate schedule factor')
        self.parser.add_argument('--milestones', default=[75000], nargs="+", type=int,
                                 help="learning rate schedule (iterations)")
        self.parser.add_argument('--warm_up_iter', default=2000, type=int, help='number of total iterations for warmup')

        '''Condition'''
        self.parser.add_argument('--cond_drop_prob', type=float, default=0.1,
                                 help='Drop ratio of condition, for classifier-free guidance')
        self.parser.add_argument("--seed", default=3407, type=int, help="Seed")

        self.parser.add_argument('--is_continue', action="store_true", help='Is this trial continuing previous state?')
        self.parser.add_argument('--gumbel_sample', action="store_true",
                                 help='Strategy for token sampling, True: Gumbel sampling, False: Categorical sampling')
        self.parser.add_argument('--share_weight', action="store_true",
                                 help='Whether to share weight for projection/embedding, for residual transformer.')

        self.parser.add_argument('--log_every', type=int, default=50,
                                 help='Frequency of printing training progress, (iteration)')
        # self.parser.add_argument('--save_every_e', type=int, default=100, help='Frequency of printing training progress')
        self.parser.add_argument('--eval_every_e', type=int, default=10,
                                 help='Frequency of animating eval results, (epoch)')
        self.parser.add_argument('--save_latest', type=int, default=1000,
                                 help='Frequency of saving checkpoint, (iteration)')

        self.parser.add_argument("--nb_code", type=int, default=512, help="nb of embedding")
        self.parser.add_argument("--embed-dim-gpt", type=int, default=1024, help="embedding dimension")
        self.parser.add_argument("--clip-dim", type=int, default=512, help="latent dimension in the clip feature")
        self.parser.add_argument("--block-size", type=int, default=151, help="seq len")
        self.parser.add_argument("--num-layers", type=int, default=9, help="nb of transformer layers")
        self.parser.add_argument("--num-local-layer", type=int, default=2, help="nb of transformer local layers")
        self.parser.add_argument("--n-head-gpt", type=int, default=16, help="nb of heads")
        self.parser.add_argument("--ff-rate", type=int, default=4, help="feedforward size")
        self.parser.add_argument("--drop-out-rate", type=float, default=0.1, help="dropout ratio in the pos encoding")
        self.parser.add_argument("--if-maxtest", action='store_true', help="test in max")
        self.parser.add_argument('--pkeep', type=float, default=0.5, help='keep rate for gpt training')

        self.is_train = True

trans_bodypart_cfg = {
        'default': dict(
            # Common transformer config
            parts_code_nb={  # size of part codebooks
                'person1': 512,
                'person2': 512,

            },
            parts_embed_dim={  # dimension (size) of transformer attention block
                'person1': 256,
                'person2': 256,
            },
            # Fuse V1 config
            num_mlp_layers=3,
            # FuseV2 config
            fusev2_sub_mlp_out_features={
                'person1': 64,
                'person2': 64,
            },
            fusev2_sub_mlp_num_layers=2,
            fusev2_head_mlp_num_layers=2,
        ),
        'small': dict(
            # Common transformer config
            parts_code_nb={  # size of part codebooks
                'person1': 512,
                'person2': 512,
            },
            parts_embed_dim={  # dimension (size) of transformer attention block
                'person1': 128,
                'person2': 128,
            },
            # Fuse V1 config
            num_mlp_layers=3,
            # FuseV2 config
            fusev2_sub_mlp_out_features={
                'person1': 64,
                'person2': 64,
            },
            fusev2_sub_mlp_num_layers=2,
            fusev2_head_mlp_num_layers=2,
        ),
        'tiny': dict(
            # Common transformer config
            parts_code_nb={  # size of part codebooks
                'person1': 512,
                'person2': 512,

            },
            parts_embed_dim={  # dimension (size) of transformer attention block
                'person1': 64,
                'person2': 64,

            },
            # Fuse V1 config
            num_mlp_layers=3,
            # FuseV2 config
            fusev2_sub_mlp_out_features={
                'person1': 64,
                'person2': 64,

            },
            fusev2_sub_mlp_num_layers=2,
            fusev2_head_mlp_num_layers=2,
        ),
    }
class TrainPartOptions(BaseOptions):

    def initialize(self):
        BaseOptions.initialize(self)
        self.parser.add_argument('--batch_size', type=int, default=64, help='Batch size')
        self.parser.add_argument('--max_epoch', type=int, default=3000, help='Maximum number of epoch for training')
        # self.parser.add_argument('--max_iters', type=int, default=150_000, help='Training iterations')

        '''LR scheduler'''
        self.parser.add_argument('--lr', type=float, default=2e-4, help='Learning rate')
        self.parser.add_argument('--gamma', type=float, default=0.05, help='Learning rate schedule factor')
        self.parser.add_argument('--milestones', default=[150000], nargs="+", type=int,
                                 help="learning rate schedule (iterations)")
        self.parser.add_argument('--warm_up_iter', default=1000, type=int, help='number of total iterations for warmup')

        '''Condition'''
        self.parser.add_argument('--cond_drop_prob', type=float, default=0.1,
                                 help='Drop ratio of condition, for classifier-free guidance')
        self.parser.add_argument("--seed", default=123, type=int, help="Seed")

        self.parser.add_argument('--is_continue', action="store_true", help='Is this trial continuing previous state?')
        self.parser.add_argument('--gumbel_sample', action="store_true",
                                 help='Strategy for token sampling, True: Gumbel sampling, False: Categorical sampling')
        self.parser.add_argument('--share_weight', action="store_true",
                                 help='Whether to share weight for projection/embedding, for residual transformer.')

        self.parser.add_argument('--log_every', type=int, default=50,
                                 help='Frequency of printing training progress, (iteration)')
        # self.parser.add_argument('--save_every_e', type=int, default=100, help='Frequency of printing training progress')
        self.parser.add_argument('--eval_every_e', type=int, default=10,
                                 help='Frequency of animating eval results, (epoch)')
        self.parser.add_argument('--save_latest', type=int, default=1000,
                                 help='Frequency of saving checkpoint, (iteration)')
        self.parser.add_argument('--total-iter', default=100000, type=int, help='number of total iterations to run')
        self.parser.add_argument('--lr-scheduler', default=[200000], nargs="+", type=int,
                            help="learning rate schedule (iterations)")
        # self.parser.add_argument('--gamma', default=0.05, type=float, help="learning rate decay")

        self.parser.add_argument('--weight-decay', default=1e-6, type=float, help='weight decay')
        self.parser.add_argument('--decay-option', default='all', type=str, choices=['all', 'noVQ'],
                            help='disable weight decay on codebook')
        self.parser.add_argument('--optimizer', default='adamw', type=str, choices=['adam', 'adamw'],
                            help='disable weight decay on codebook')

        self.parser.add_argument("--code-dim", type=int, default=512, help="embedding dimension")
        self.parser.add_argument("--nb-code", type=int, default=512, help="nb of embedding (code book size)")
        self.parser.add_argument("--width", type=int, default=512, help="width of the network")
        self.parser.add_argument("--output-emb-width", type=int, default=512, help="output embedding width")

        self.parser.add_argument("--block-size", type=int, default=76, help="seq len")
        self.parser.add_argument("--embed-dim-gpt", type=int, default=512, help="embedding dimension")
        self.parser.add_argument("--clip-dim", type=int, default=512, help="latent dimension in the clip feature")
        self.parser.add_argument("--num-layers", type=int, default=2, help="nb of transformer layers")
        self.parser.add_argument("--n-head-gpt", type=int, default=8, help="nb of heads")
        self.parser.add_argument("--ff-rate", type=int, default=4, help="feedforward size")
        self.parser.add_argument("--drop-out-rate", type=float, default=0.1, help="dropout ratio in the pos encoding")


        self.parser.add_argument("--if-maxtest", action='store_true', help="test in max")
        self.parser.add_argument('--pkeep', type=float, default=0.4,
                            help='keep rate for gpt training, lower pkeep, higher mask rate')
        self.parser.add_argument("--use-pkeep-scheduler", action='store_true', help="Use pkeep scheduler")


        self.parser.add_argument("--trans-cfg", type=str, help="Base config for our part coordinating transformer")
        self.parser.add_argument("--sync-part-maskaug", action='store_true',
                            help="all parts use the same masking augmentation")
        self.parser.add_argument("--no-fuse", action='store_true', help="stop using Part-Coordinating module")
        self.parser.add_argument("--fuse-ver", type=str, default='V1_2',
                            choices=['V1', 'V1_2', 'V1_3', 'V1_4', 'V2', 'V2_2'], help="Fuse module structure")
        self.parser.add_argument("--alpha", type=float, default=1.0, help="Part Coordinating strength.")
        self.parser.add_argument("--dilation-growth-rate", type=int, default=3, help="dilation growth rate")

        self.is_train = True
class TrainLenEstOptions():
    def __init__(self):
        self.parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        self.parser.add_argument('--name', type=str, default="test", help='Name of this trial')
        self.parser.add_argument("--gpu_id", type=int, default=-1, help='GPU id')

        self.parser.add_argument('--dataset_name', type=str, default='t2m', help='Dataset Name')
        self.parser.add_argument('--checkpoints_dir', type=str, default='./checkpoints', help='models are saved here')

        self.parser.add_argument('--batch_size', type=int, default=64, help='Batch size')

        self.parser.add_argument("--unit_length", type=int, default=4, help="Length of motion")
        self.parser.add_argument("--max_text_len", type=int, default=50, help="Length of motion")

        self.parser.add_argument('--max_epoch', type=int, default=300, help='Training iterations')

        self.parser.add_argument('--lr', type=float, default=1e-4, help='Layers of GRU')

        self.parser.add_argument('--is_continue', action="store_true", help='Training iterations')

        self.parser.add_argument('--log_every', type=int, default=50, help='Frequency of printing training progress')
        self.parser.add_argument('--save_every_e', type=int, default=5, help='Frequency of printing training progress')
        self.parser.add_argument('--eval_every_e', type=int, default=3, help='Frequency of printing training progress')
        self.parser.add_argument('--save_latest', type=int, default=500, help='Frequency of printing training progress')

    def parse(self):
        self.opt = self.parser.parse_args()
        self.opt.is_train = True
        # args = vars(self.opt)
        return self.opt
