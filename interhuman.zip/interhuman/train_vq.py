import os
from os.path import join as pjoin

import torch
from torch.utils.data import DataLoader

from models.vq.model import RVQVAE
from models.vq.vq_trainer import RVQTokenizerTrainer
from options.vq_option import arg_parse

from utils import paramUtil
import numpy as np
from data.t2m_dataset import MotionDataset
from models.t2m_eval_wrapper import EvaluatorModelWrapper
from utils.get_opt import get_opt
from motion_loaders.dataset_motion_loader import get_dataset_motion_loader

from datasets.interhuman import InterHumanMotion,InterHumanMotion_two,MotionDataset_two_intergen,MotionDataset_intergen
from utils.motion_process import recover_from_ric
from utils.plot_script import plot_3d_motion
from utils.fixseed import fixseed
from configs import get_config
os.environ["OMP_NUM_THREADS"] = "1"

def plot_t2m(data, save_dir):
    data1 = data[:, :, :262]
    data2 = data[:, :, 262:524]
    data1 = train_dataset.inv_transform(data1)
    data2 = train_dataset.inv_transform(data2)
    data1_tensor = torch.from_numpy(data1)
    data2_tensor = torch.from_numpy(data2)
    data = torch.cat([data1_tensor, data2_tensor], dim=-1)
    data=data.cpu().numpy()
    try:
        for i in range(len(data)):
            mp_joint = [None, None]
            joint_data = data[i]
            mp_joint[0] = joint_data[:, :22 * 3].reshape(-1, 22, 3)
            mp_joint[1] = joint_data[:, 262:262+22 * 3].reshape(-1, 22, 3)
            save_path = pjoin(save_dir, '%02d.mp4' % (i))

            plot_3d_motion(save_path, kinematic_chain, mp_joint, title="None", fps=fps, radius=radius)
    except Exception as e:
        print("Other error:", str(e))
def plot_t2m2(data, save_dir):
    try:
        for i in range(len(data)):
            mp_joint = [None, None]
            joint_data = data[i]
            mp_joint[0] = joint_data[:, :22 * 3].reshape(-1, 22, 3)
            mp_joint[1] = joint_data[:, 262:262 + 22 * 3].reshape(-1, 22, 3)
            save_path = pjoin(save_dir, '%02d.mp4' % (i))

            plot_3d_motion(save_path, kinematic_chain, mp_joint, title="None", fps=fps, radius=radius)
    except Exception as e:
        print("Other error:", str(e))

if __name__ == "__main__":
    # torch.autograd.set_detect_anomaly(True)
    opt = arg_parse(True)
    fixseed(opt.seed)

    opt.device = torch.device("cpu" if opt.gpu_id == -1 else "cuda:" + str(opt.gpu_id))
    print(f"Using Device: {opt.device}")

    opt.save_root = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.name)
    opt.model_dir = pjoin(opt.save_root, 'model')
    opt.meta_dir = pjoin(opt.save_root, 'meta')
    opt.eval_dir = pjoin(opt.save_root, 'animation')
    opt.log_dir = pjoin(opt.save_root,'./log/vq/', opt.dataset_name, opt.name)
    opt.eval_log_dir=pjoin(opt.save_root, 'eval.txt')

    os.makedirs(opt.model_dir, exist_ok=True)
    os.makedirs(opt.meta_dir, exist_ok=True)
    os.makedirs(opt.eval_dir, exist_ok=True)
    os.makedirs(opt.log_dir, exist_ok=True)
    with open(opt.eval_log_dir, 'w') as f:
        f.write('')

    if opt.dataset_name == "inetrhuman":
        opt.data_root = 'interhuman/dataset/intergentwoperson'

        opt.joints_num = 22
        dim_pose = 262
        fps = 20
        radius = 4
        kinematic_chain = paramUtil.t2m_kinematic_chain
        dataset_opt_path = './checkpoints/t2m/Comp_v6_KLD005/opt.txt'
    else:
        raise KeyError('Dataset Does not Exists')

    evalmodel_cfg = get_config("configs/eval_model.yaml")
    eval_wrapper = EvaluatorModelWrapper(evalmodel_cfg, torch.device('cuda'))

    mean = np.load(pjoin(opt.data_root, 'global_mean.npy'))
    std = np.load(pjoin(opt.data_root, 'global_std.npy'))


    net = RVQVAE(opt,
                dim_pose,
                opt.nb_code,
                opt.code_dim,
                opt.code_dim,
                opt.down_t,
                opt.stride_t,
                opt.width,
                opt.depth,
                opt.dilation_growth_rate,
                opt.vq_act,
                opt.vq_norm)

    pc_vq = sum(param.numel() for param in net.parameters())
    print(net)


    print('Total parameters of all models: {}M'.format(pc_vq/1000_000))

    trainer = RVQTokenizerTrainer(opt,mean,std, vq_model=net)
    data_cfg_train = get_config("configs/datasets.yaml").interhuman
    train_dataset = MotionDataset_intergen(data_cfg_train, mean, std, opt.window_size)

    data_cfg_val = get_config("configs/datasets.yaml").interhuman_val
    val_dataset = MotionDataset_intergen(data_cfg_val, mean, std, opt.window_size)


    train_loader = DataLoader(train_dataset, batch_size=opt.batch_size, drop_last=True, num_workers=4,
                              shuffle=True, pin_memory=True)
    val_loader = DataLoader(val_dataset, batch_size=opt.batch_size, drop_last=True, num_workers=4,
                            shuffle=True, pin_memory=True)
    data_cfg_val = get_config("configs/datasets.yaml").interhuman_val
    eval_val_loader, _ = get_dataset_motion_loader(data_cfg_val, mean, std, 96)
    trainer.train(train_loader, val_loader, eval_val_loader, eval_wrapper, plot_t2m,plot_t2m2)