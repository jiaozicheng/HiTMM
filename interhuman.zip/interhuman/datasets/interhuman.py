import numpy as np
import torch
import random

from torch.utils import data
from tqdm import tqdm
from os.path import join as pjoin
import os
from utils.utils import *
from utils.plot_script import *
from utils.preprocess import *
import json


class MotionNormalizerTorch():
    def __init__(self):
        mean = np.load('/opt/data/private/myfile/MMM-main/dataset/intergentwoperson/global_mean.npy')
        std = np.load('/opt/data/private/myfile/MMM-main/dataset/intergentwoperson/global_std.npy')
        self.motion_mean = torch.from_numpy(mean).float()
        self.motion_std = torch.from_numpy(std).float()

    def forward(self, x):
        device = x.device
        x = x.clone()
        x = (x - self.motion_mean.to(device)) / self.motion_std.to(device)
        return x

    def backward(self, x, global_rt=False):
        device = x.device
        x = x.clone()
        x = x * self.motion_std.to(device) + self.motion_mean.to(device)
        return x

class InterHumanMotion_two(data.Dataset):
    def __init__(self, opt,mean, std,window_size):
        self.opt = opt
        self.max_cond_length = 1
        self.min_cond_length = 1
        self.max_gt_length = 300
        self.min_gt_length = window_size
        self.window_size=window_size
        self.mean=mean
        self.std=std


        self.max_length = self.max_cond_length + self.max_gt_length - 1
        self.min_length = self.min_cond_length + self.min_gt_length - 1

        self.data_list = []
        self.data = []
        self.motion_dict = {}
        self.lengths = []

        ignore_list = []
        try:
            ignore_list = open(os.path.join(opt.DATA_ROOT, "split", "ignore_list.txt"), "r").readlines()
        except Exception as e:
            print(e)
        data_list = []
        if self.opt.MODE == "train":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "split", "train.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "val":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "split", "val.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "test":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "split", "test.txt"), "r").readlines()
            except Exception as e:
                print(e)

        # random.shuffle(data_list)

        for root, dirs, files in os.walk(pjoin(opt.DATA_ROOT)):
            for file in tqdm(files):
                if file.endswith(".npy") and "person1" in root:
                    motion_name = file.split(".")[0]
                    if file.split(".")[0] + "\n" in ignore_list:  # or int(motion_name)>1000
                        print("ignore: ", file)
                        continue
                    if file.split(".")[0] + "\n" not in data_list:
                        continue
                    file_path_person1 = pjoin(root, file)
                    file_path_person2 = pjoin(root.replace("person1", "person2"), file)

                    motion1, motion1_swap = load_motion(file_path_person1, self.min_length, swap=True)
                    motion2, motion2_swap = load_motion(file_path_person2, self.min_length, swap=True)
                    if motion1 is None:
                        continue

                    def process_both_motions(motion1, motion2):
                        motion1, root_quat_init1, root_pos_init1 = process_motion_np(motion1, 0.001, 0, n_joints=22)
                        motion2, root_quat_init2, root_pos_init2 = process_motion_np(motion2, 0.001, 0, n_joints=22)
                        r_relative = qmul_np(root_quat_init2, qinv_np(root_quat_init1))
                        angle = np.arctan2(r_relative[:, 2:3], r_relative[:, 0:1])

                        xz = qrot_np(root_quat_init1, root_pos_init2 - root_pos_init1)[:, [0, 2]]
                        relative = np.concatenate([angle, xz], axis=-1)[0]
                        motion2 = rigid_transform(relative, motion2)
                        return motion1, motion2

                    motion1, motion2 = process_both_motions(motion1, motion2)
                    motion = np.concatenate((motion1, motion2), axis=1)
                    motion1_swap, motion2_swap = process_both_motions(motion1_swap, motion2_swap)
                    motion_swap = np.concatenate((motion1_swap, motion2_swap), axis=1)
                    self.data.extend([motion,motion_swap])
                    self.lengths.extend([motion.shape[0] - self.window_size,motion_swap.shape[0] - self.window_size])

        self.cumsum = np.cumsum([0] + self.lengths)
        print("Total number of motions {}, snippets {}".format(len(self.data), self.cumsum[-1]))

    def __len__(self):
        return self.cumsum[-1]

    def inv_transform(self, data):
        return data * self.std + self.mean

    def __getitem__(self, item):
        if item != 0:
            motion_id = np.searchsorted(self.cumsum, item) - 1
            idx = item - self.cumsum[motion_id] - 1
        else:
            motion_id = 0
            idx = 0
        gt_motion = self.data[motion_id][idx:idx + self.window_size]
        assert len(gt_motion) == self.window_size
        gt_motion1 = gt_motion[:, :262]
        gt_motion2 = gt_motion[:, 262:524]
        gt_motion1 = (gt_motion1 - self.mean) / self.std
        gt_motion2 = (gt_motion2 - self.mean) / self.std
        motion_len=gt_motion.shape[0]
        return gt_motion1,gt_motion2,motion_len

class InterHumanMotion(data.Dataset):
    def __init__(self, opt,mean, std,window_size,window_stride):
        self.opt = opt
        self.max_cond_length = 1
        self.min_cond_length = 1
        self.max_gt_length = 300
        self.min_gt_length = window_size
        self.window_size=window_size
        self.window_stride=window_stride
        self.mean=mean
        self.std=std
        self.normalizer = MotionNormalizerTorch()

        self.max_length = self.max_cond_length + self.max_gt_length - 1
        self.min_length = self.min_cond_length + self.min_gt_length - 1

        self.data_list = []
        self.data = []
        self.motion_dict = {}
        self.lengths = []

        ignore_list = []
        try:
            ignore_list = open(os.path.join(opt.DATA_ROOT, "split", "ignore_list.txt"), "r").readlines()
        except Exception as e:
            print(e)
        data_list = []
        if self.opt.MODE == "train":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "split", "train.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "val":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "split", "val.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "test":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "split", "test.txt"), "r").readlines()
            except Exception as e:
                print(e)

        # random.shuffle(data_list)

        for root, dirs, files in os.walk(pjoin(opt.DATA_ROOT)):
            for file in tqdm(files):
                if file.endswith(".npy") and "person1" in root:
                    motion_name = file.split(".")[0]
                    if file.split(".")[0] + "\n" in ignore_list:  # or int(motion_name)>1000
                        print("ignore: ", file)
                        continue
                    if file.split(".")[0] + "\n" not in data_list:
                        continue
                    file_path_person1 = pjoin(root, file)
                    file_path_person2 = pjoin(root.replace("person1", "person2"), file)

                    motion1, motion1_swap = load_motion(file_path_person1, self.min_length, swap=True)
                    motion2, motion2_swap = load_motion(file_path_person2, self.min_length, swap=True)
                    if motion1 is None:
                        continue

                    def process_both_motions(motion1, motion2):
                        motion1, root_quat_init1, root_pos_init1 = process_motion_np(motion1, 0.001, 0, n_joints=22)
                        motion2, root_quat_init2, root_pos_init2 = process_motion_np(motion2, 0.001, 0, n_joints=22)
                        r_relative = qmul_np(root_quat_init2, qinv_np(root_quat_init1))
                        angle = np.arctan2(r_relative[:, 2:3], r_relative[:, 0:1])

                        xz = qrot_np(root_quat_init1, root_pos_init2 - root_pos_init1)[:, [0, 2]]
                        relative = np.concatenate([angle, xz], axis=-1)[0]
                        motion2 = rigid_transform(relative, motion2)
                        return motion1, motion2

                    motion1, motion2 = process_both_motions(motion1, motion2)
                    motion1_swap, motion2_swap = process_both_motions(motion1_swap, motion2_swap)

                    self.data.extend([motion1,
                                             motion1_swap,
                                             motion2,
                                             motion2_swap])
                    self.lengths.extend([motion1.shape[0] - self.window_size,motion1_swap.shape[0] - self.window_size,
                                        motion2.shape[0] - self.window_size,motion2_swap.shape[0] - self.window_size])

        self.cumsum = np.cumsum([0] + self.lengths)
        print("Total number of motions {}, snippets {}".format(len(self.data), self.cumsum[-1]))

    def __len__(self):
        return self.cumsum[-1]

    def inv_transform(self, data):
        return data * self.std + self.mean

    def __getitem__(self, item):
        if item != 0:
            motion_id = np.searchsorted(self.cumsum, item) - 1
            idx = item - self.cumsum[motion_id] - 1
        else:
            motion_id = 0
            idx = 0
        gt_motion = self.data[motion_id][idx:idx + self.window_size]

        assert len(gt_motion) == self.window_size
        gt_motion = (gt_motion - self.mean) / self.std
        return gt_motion
class InterHumanDataset(data.Dataset):
    def _safe_read_text_file(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                # 在这里添加 replace 操作
                return [line.replace("\n", "").strip() for line in file]
        except UnicodeDecodeError:
            print(f"UnicodeDecodeError encountered in file: {file_path}")
            return []
    def __init__(self, opt,nor=True):
        self.opt = opt
        self.max_cond_length = 1
        self.min_cond_length = 1
        self.max_gt_length = 300
        self.min_gt_length = 15

        self.max_length = self.max_cond_length + self.max_gt_length - 1
        self.min_length = self.min_cond_length + self.min_gt_length - 1

        self.motion_rep = opt.MOTION_REP
        self.data_list = []
        self.motion_dict = {}
        self.nor=nor
        self.normalizer = MotionNormalizer()

        self.cache = opt.CACHE

        ignore_list = []
        try:
            ignore_list = open(os.path.join(opt.DATA_ROOT, "ignore_list.txt"), "r").readlines()
        except Exception as e:
            print(e)
        data_list = []
        if self.opt.MODE == "train":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "train.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "val":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "val.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "test":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "test.txt"), "r").readlines()
            except Exception as e:
                print(e)

        random.shuffle(data_list)
        # data_list = data_list[:70]

        index = 0
        for root, dirs, files in os.walk(pjoin(opt.DATA_ROOT)):
            for file in tqdm(files):
                if file.endswith(".npy") and "person1" in root:
                    motion_name = file.split(".")[0]
                    if file.split(".")[0] + "\n" in ignore_list:  # or int(motion_name)>1000
                        print("ignore: ", file)
                        continue
                    if file.split(".")[0] + "\n" not in data_list:
                        continue
                    file_path_person1 = pjoin(root, file)
                    file_path_person2 = pjoin(root.replace("person1", "person2"), file)
                    text_path = file_path_person1.replace("motions_processed", "annots").replace("person1", "").replace(
                        "npy", "txt")

                    texts = [item.replace("\n", "") for item in open(text_path, "r").readlines()]
                    texts_swap = [
                        item.replace("\n", "").replace("left", "tmp").replace("right", "left").replace("tmp", "right")
                        .replace("clockwise", "tmp").replace("counterclockwise", "clockwise").replace("tmp",
                                                                                                      "counterclockwise")
                        for item in texts]

                    motion1, motion1_swap = load_motion(file_path_person1, self.min_length, swap=True)
                    motion2, motion2_swap = load_motion(file_path_person2, self.min_length, swap=True)
                    if motion1 is None:
                        continue

                    if self.cache:
                        self.motion_dict[index] = [motion1, motion2]
                        self.motion_dict[index + 1] = [motion1_swap, motion2_swap]
                    else:
                        self.motion_dict[index] = [file_path_person1, file_path_person2]
                        self.motion_dict[index + 1] = [file_path_person1, file_path_person2]

                    self.data_list.append({
                        # "idx": idx,
                        "name": motion_name,
                        "motion_id": index,
                        "swap": False,
                        "texts": texts
                    })
                    if opt.MODE == "train":
                        self.data_list.append({
                            # "idx": idx,
                            "name": motion_name + "_swap",
                            "motion_id": index + 1,
                            "swap": True,
                            "texts": texts_swap
                        })

                    index += 2

        print("total dataset: ", len(self.data_list))

    def real_len(self):
        return len(self.data_list)

    def __len__(self):
        return self.real_len() * 1

    def __getitem__(self, item):
        idx = item % self.real_len()
        data = self.data_list[idx]

        name = data["name"]
        motion_id = data["motion_id"]
        swap = data["swap"]
        text = random.choice(data["texts"]).strip()

        if self.cache:
            full_motion1, full_motion2 = self.motion_dict[motion_id]
        else:
            file_path1, file_path2 = self.motion_dict[motion_id]
            motion1, motion1_swap = load_motion(file_path1, self.min_length, swap=swap)
            motion2, motion2_swap = load_motion(file_path2, self.min_length, swap=swap)
            if swap:
                full_motion1 = motion1_swap
                full_motion2 = motion2_swap
            else:
                full_motion1 = motion1
                full_motion2 = motion2

        length = full_motion1.shape[0]
        if length > self.max_length:
            idx = random.choice(list(range(0, length - self.max_gt_length, 1)))
            gt_length = self.max_gt_length
            motion1 = full_motion1[idx:idx + gt_length]
            motion2 = full_motion2[idx:idx + gt_length]

        else:
            idx = 0
            gt_length = min(length - idx, self.max_gt_length)
            motion1 = full_motion1[idx:idx + gt_length]
            motion2 = full_motion2[idx:idx + gt_length]

        if np.random.rand() > 0.5:
            motion1, motion2 = motion2, motion1
        motion1, root_quat_init1, root_pos_init1 = process_motion_np(motion1, 0.001, 0, n_joints=22)
        motion2, root_quat_init2, root_pos_init2 = process_motion_np(motion2, 0.001, 0, n_joints=22)
        r_relative = qmul_np(root_quat_init2, qinv_np(root_quat_init1))
        angle = np.arctan2(r_relative[:, 2:3], r_relative[:, 0:1])

        xz = qrot_np(root_quat_init1, root_pos_init2 - root_pos_init1)[:, [0, 2]]
        relative = np.concatenate([angle, xz], axis=-1)[0]
        motion2 = rigid_transform(relative, motion2)

        gt_motion1 = motion1
        gt_motion2 = motion2
        m_length=len(gt_motion1)

        m_length = (m_length // 4) * 4
        idx = random.randint(0, len(gt_motion1) - m_length)
        gt_motion1 = gt_motion1[idx:idx + m_length]
        gt_motion2 = gt_motion2[idx:idx + m_length]

        if self.normalize:
            gt_motion1 = self.normalizer.forward(gt_motion1)
            gt_motion2 = self.normalizer.forward(gt_motion2)
        gt_length = len(gt_motion1)
        if gt_length < self.max_gt_length:
            padding_len = self.max_gt_length - gt_length
            D = gt_motion1.shape[1]
            padding_zeros = np.zeros((padding_len, D))
            gt_motion1 = np.concatenate((gt_motion1, padding_zeros), axis=0)
            gt_motion2 = np.concatenate((gt_motion2, padding_zeros), axis=0)

        assert len(gt_motion1) == self.max_gt_length
        assert len(gt_motion2) == self.max_gt_length

        if np.random.rand() > 0.5:
            gt_motion1, gt_motion2 = gt_motion2, gt_motion1

        return name, text, gt_motion1, gt_motion2, gt_length


class InterHumanDataset_test(data.Dataset):
    def _safe_read_text_file(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                # 在这里添加 replace 操作
                return [line.replace("\n", "").strip() for line in file]
        except UnicodeDecodeError:
            print(f"UnicodeDecodeError encountered in file: {file_path}")
            return []
    def __init__(self, opt,nor=True):
        self.opt = opt
        self.max_cond_length = 1
        self.min_cond_length = 1
        self.max_gt_length = 300
        self.min_gt_length = 15

        self.max_length = self.max_cond_length + self.max_gt_length - 1
        self.min_length = self.min_cond_length + self.min_gt_length - 1

        self.motion_rep = opt.MOTION_REP
        self.data_list = []
        self.motion_dict = {}
        self.nor=nor
        self.normalizer = MotionNormalizer()

        self.cache = opt.CACHE

        ignore_list = []
        try:
            ignore_list = open(os.path.join(opt.DATA_ROOT, "ignore_list.txt"), "r").readlines()
        except Exception as e:
            print(e)
        data_list = []
        if self.opt.MODE == "train":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "train.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "val":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "val.txt"), "r").readlines()
            except Exception as e:
                print(e)
        elif self.opt.MODE == "test":
            try:
                data_list = open(os.path.join(opt.DATA_ROOT, "test.txt"), "r").readlines()
            except Exception as e:
                print(e)

        random.shuffle(data_list)
        # data_list = data_list[:70]

        index = 0
        for root, dirs, files in os.walk(pjoin(opt.DATA_ROOT)):
            for file in tqdm(files):
                if file.endswith(".npy") and "person1" in root:
                    motion_name = file.split(".")[0]
                    if file.split(".")[0] + "\n" in ignore_list:  # or int(motion_name)>1000
                        print("ignore: ", file)
                        continue
                    if file.split(".")[0] + "\n" not in data_list:
                        continue
                    file_path_person1 = pjoin(root, file)
                    file_path_person2 = pjoin(root.replace("person1", "person2"), file)
                    text_path = file_path_person1.replace("motions_processed", "annots").replace("person1", "").replace(
                        "npy", "txt")

                    texts = [item.replace("\n", "") for item in open(text_path, "r").readlines()]
                    texts_swap = [
                        item.replace("\n", "").replace("left", "tmp").replace("right", "left").replace("tmp", "right")
                        .replace("clockwise", "tmp").replace("counterclockwise", "clockwise").replace("tmp",
                                                                                                      "counterclockwise")
                        for item in texts]

                    motion1, motion1_swap = load_motion(file_path_person1, self.min_length, swap=True)
                    motion2, motion2_swap = load_motion(file_path_person2, self.min_length, swap=True)
                    if motion1 is None:
                        continue

                    if self.cache:
                        self.motion_dict[index] = [motion1, motion2]
                        self.motion_dict[index + 1] = [motion1_swap, motion2_swap]
                    else:
                        self.motion_dict[index] = [file_path_person1, file_path_person2]
                        self.motion_dict[index + 1] = [file_path_person1, file_path_person2]

                    self.data_list.append({
                        # "idx": idx,
                        "name": motion_name,
                        "motion_id": index,
                        "swap": False,
                        "texts": texts
                    })
                    if opt.MODE == "train":
                        self.data_list.append({
                            # "idx": idx,
                            "name": motion_name + "_swap",
                            "motion_id": index + 1,
                            "swap": True,
                            "texts": texts_swap
                        })

                    index += 2

        print("total dataset: ", len(self.data_list))

    def real_len(self):
        return len(self.data_list)

    def __len__(self):
        return self.real_len() * 1

    def __getitem__(self, item):
        idx = item % self.real_len()
        data = self.data_list[idx]

        name = data["name"]
        motion_id = data["motion_id"]
        swap = data["swap"]
        text = random.choice(data["texts"]).strip()

        if self.cache:
            full_motion1, full_motion2 = self.motion_dict[motion_id]
        else:
            file_path1, file_path2 = self.motion_dict[motion_id]
            motion1, motion1_swap = load_motion(file_path1, self.min_length, swap=swap)
            motion2, motion2_swap = load_motion(file_path2, self.min_length, swap=swap)
            if swap:
                full_motion1 = motion1_swap
                full_motion2 = motion2_swap
            else:
                full_motion1 = motion1
                full_motion2 = motion2

        length = full_motion1.shape[0]
        if length > self.max_length:
            idx = random.choice(list(range(0, length - self.max_gt_length, 1)))
            gt_length = self.max_gt_length
            motion1 = full_motion1[idx:idx + gt_length]
            motion2 = full_motion2[idx:idx + gt_length]

        else:
            idx = 0
            gt_length = min(length - idx, self.max_gt_length)
            motion1 = full_motion1[idx:idx + gt_length]
            motion2 = full_motion2[idx:idx + gt_length]

        if np.random.rand() > 0.5:
            motion1, motion2 = motion2, motion1
        motion1, root_quat_init1, root_pos_init1 = process_motion_np(motion1, 0.001, 0, n_joints=22)
        motion2, root_quat_init2, root_pos_init2 = process_motion_np(motion2, 0.001, 0, n_joints=22)
        r_relative = qmul_np(root_quat_init2, qinv_np(root_quat_init1))
        angle = np.arctan2(r_relative[:, 2:3], r_relative[:, 0:1])

        xz = qrot_np(root_quat_init1, root_pos_init2 - root_pos_init1)[:, [0, 2]]
        relative = np.concatenate([angle, xz], axis=-1)[0]
        motion2 = rigid_transform(relative, motion2)

        gt_motion1 = motion1
        gt_motion2 = motion2
        m_length=len(gt_motion1)
        m_length = (m_length // 4) * 4
        gt_motion1 = gt_motion1[idx:idx + m_length]
        gt_motion2 = gt_motion2[idx:idx + m_length]

        if self.normalize:
            gt_motion1 = self.normalizer.forward(gt_motion1)
            gt_motion2 = self.normalizer.forward(gt_motion2)
        gt_length = len(gt_motion1)
        if gt_length < self.max_gt_length:
            padding_len = self.max_gt_length - gt_length
            D = gt_motion1.shape[1]
            padding_zeros = np.zeros((padding_len, D))
            gt_motion1 = np.concatenate((gt_motion1, padding_zeros), axis=0)
            gt_motion2 = np.concatenate((gt_motion2, padding_zeros), axis=0)

        assert len(gt_motion1) == self.max_gt_length
        assert len(gt_motion2) == self.max_gt_length

        if np.random.rand() > 0.5:
            gt_motion1, gt_motion2 = gt_motion2, gt_motion1

        return name, text, gt_motion1, gt_motion2, gt_length