import os
import torch
import numpy as np

from torch.utils.data import DataLoader
from os.path import join as pjoin

from models.mask_transformer.cross_transformer import MaskTransformer
from models.mask_transformer.transformer_trainer import MaskTransformerTrainer
from models.vq.model import RVQVAE
from options.train_option import TrainT2MOptions
from utils.plot_script import plot_3d_motion
from utils.motion_process import recover_from_ric
from utils.get_opt import get_opt
from utils.fixseed import fixseed
from utils.paramUtil import t2m_kinematic_chain, kit_kinematic_chain
from motion_loaders.dataset_motion_loader import *
from models.t2m_eval_wrapper import EvaluatorModelWrapper,build_models
import shutil
from configs import get_config
from tqdm import tqdm



def plot_t2m(data, save_dir):

    try:
        for i in range(len(data)):
            mp_joint = [None, None]
            joint_data = data[i]
            mp_joint[0] = joint_data[:, :22 * 3].reshape(-1, 22, 3)
            mp_joint[1] = joint_data[:, 262:262 + 22 * 3].reshape(-1, 22, 3)
            save_path = pjoin(save_dir, '%02d.mp4' % (i))

            plot_3d_motion(save_path, kinematic_chain, mp_joint, title="None", fps=fps, radius=radius)
    except Exception as e:
        print("Other error:", str(e))

def load_vq_model():
    opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.vq_name, 'opt.txt')
    vq_opt = get_opt(opt_path, opt.device)
    vq_model = RVQVAE(vq_opt,
                      dim_pose,
                      vq_opt.nb_code,
                      vq_opt.code_dim,
                      vq_opt.output_emb_width,
                      vq_opt.down_t,
                      vq_opt.stride_t,
                      vq_opt.width,
                      vq_opt.depth,
                      vq_opt.dilation_growth_rate,
                      vq_opt.vq_act,
                      vq_opt.vq_norm)
    ckpt = torch.load(pjoin(vq_opt.checkpoints_dir, vq_opt.dataset_name, vq_opt.name, 'model', 'latest.tar'),
                            map_location='cpu')
    model_key = 'vq_model' if 'vq_model' in ckpt else 'net'
    vq_epoch = ckpt['ep'] if 'ep' in ckpt else -1
    vq_model.load_state_dict(ckpt[model_key])
    print(f'Loading VQ Model {opt.vq_name} Completed!, Epoch {vq_epoch}')
    return vq_model, vq_opt

def create_or_reset_dir(directory):
    if os.path.exists(directory):
        # 删除目录及其内容
        shutil.rmtree(directory)
        # 创建目录
    os.makedirs(directory)

if __name__ == '__main__':
    parser = TrainT2MOptions()
    opt = parser.parse()
    fixseed(opt.seed)

    opt.device = torch.device("cuda")
    torch.autograd.set_detect_anomaly(True)

    opt.save_root = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.name)
    opt.model_dir = pjoin(opt.save_root, 'model')
    # opt.meta_dir = pjoin(opt.save_root, 'meta')
    opt.eval_dir = pjoin(opt.save_root, 'animation')
    opt.log_dir = pjoin(opt.save_root,'./log/t2m/', opt.dataset_name, opt.name)
    opt.eval_log_dir=pjoin(opt.save_root, 'eval.txt')

    os.makedirs(opt.model_dir, exist_ok=True)
    # os.makedirs(opt.meta_dir, exist_ok=True)
    os.makedirs(opt.eval_dir, exist_ok=True)
    os.makedirs(opt.log_dir, exist_ok=True)
    with open(opt.eval_log_dir, 'w') as f:  # 'w'模式会创建文件
        f.write('')  # 在文件中写入空内容或其他初始化内容

    if opt.dataset_name == 'interhuman':
        opt.data_root = 'interhuman/dataset/intergen'
        opt.joints_num = 44
        opt.max_motion_len = 55
        dim_pose = 262
        radius = 4
        fps = 20
        kinematic_chain = t2m_kinematic_chain

    else:
        raise KeyError('Dataset Does Not Exist')

    opt.text_dir = pjoin(opt.data_root, 'annots')

    vq_model, vq_opt = load_vq_model()

    clip_version = 'ViT-L/14@336px'

    opt.num_tokens = vq_opt.nb_code

    t2m_transformer = MaskTransformer(
                                      code_dim=vq_opt.code_dim,
                                      cond_mode='text',
                                      latent_dim=opt.latent_dim,
                                      ff_size=opt.ff_size,
                                      num_layers=opt.n_layers,
                                      num_heads=opt.n_heads,
                                      dropout=opt.dropout,
                                      clip_dim=768,
                                      cond_drop_prob=opt.cond_drop_prob,
                                      clip_version=clip_version,
                                      opt=opt)

    all_params = 0
    pc_transformer = sum(param.numel() for param in t2m_transformer.parameters_wo_clip())

    # print(t2m_transformer)
    # print("Total parameters of t2m_transformer net: {:.2f}M".format(pc_transformer / 1000_000))
    all_params += pc_transformer

    print('Total parameters of all models: {:.2f}M'.format(all_params / 1000_000))

    mean = np.load(pjoin(opt.data_root, 'global_mean.npy'))
    std = np.load(pjoin(opt.data_root, 'global_std.npy'))


    data_cfg_train = get_config("configs/datasets.yaml").interhuman
    train_loader, _ = get_dataset_motion_loader_t2m(data_cfg_train, opt.batch_size)

    data_cfg_val = get_config("configs/datasets.yaml").interhuman_val
    val_loader, _ = get_dataset_motion_loader_t2m_eval(data_cfg_val, mean, std, opt.batch_size)


    evalmodel_cfg = get_config("configs/eval_model.yaml")

    eval_wrapper = EvaluatorModelWrapper(evalmodel_cfg, torch.device('cuda'))



    trainer = MaskTransformerTrainer(opt, t2m_transformer, vq_model, mean, std)

    trainer.train(train_loader, val_loader, val_loader, eval_wrapper=eval_wrapper, plot_eval=plot_t2m)