import os

import clip
import numpy as np
import torch
from scipy import linalg

# import visualization.plot_3d_global as plot_3d
from utils.motion_process import recover_from_ric
from exit.utils import get_model, visualize_2motions, generate_src_mask
from tqdm import tqdm
from utils.metrics import *

def tensorborad_add_video_xyz(writer, xyz, nb_iter, tag, nb_vis=4, title_batch=None, outname=None):
    xyz = xyz[:1]
    bs, seq = xyz.shape[:2]
    xyz = xyz.reshape(bs, seq, -1, 3)
    plot_xyz = plot_3d.draw_to_batch(xyz.cpu().numpy(), title_batch, outname)
    plot_xyz = np.transpose(plot_xyz, (0, 1, 4, 2, 3))
    writer.add_video(tag, plot_xyz, nb_iter, fps=20)


@torch.no_grad()
def evaluation_vqvae(out_dir, val_loader, net, logger, writer, nb_iter, best_fid, best_iter, best_div, best_top1,
                     best_top2, best_top3, best_matching, eval_wrapper, draw=True, save=True, savegif=False,
                     savenpy=False):
    net.eval()
    nb_sample = 0

    draw_org = []
    draw_pred = []
    draw_text = []

    motion_annotation_list = []
    motion_pred_list = []

    R_precision_real = 0
    R_precision = 0

    nb_sample = 0
    matching_score_real = 0
    matching_score_pred = 0
    for batch in val_loader:
        word_embeddings, pos_one_hots, caption, sent_len, motion, m_length, token, name = batch

        motion = motion.cuda()
        et, em = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, motion, m_length)
        bs, seq = motion.shape[0], motion.shape[1]

        num_joints = 21 if motion.shape[-1] == 251 else 22

        pred_pose_eval = torch.zeros((bs, seq, motion.shape[-1])).cuda()

        for i in range(bs):
            pose = val_loader.dataset.inv_transform(motion[i:i + 1, :m_length[i], :].detach().cpu().numpy())
            # pose_xyz = recover_from_ric(torch.from_numpy(pose).float().cuda(), num_joints)

            pred_pose, loss_commit, perplexity = net(motion[i:i + 1, :m_length[i]])
            # pred_denorm = val_loader.dataset.inv_transform(pred_pose.detach().cpu().numpy())
            # pred_xyz = recover_from_ric(torch.from_numpy(pred_denorm).float().cuda(), num_joints)

            # if savenpy:
            #     np.save(os.path.join(out_dir, name[i]+'_gt.npy'), pose_xyz[:, :m_length[i]].cpu().numpy())
            #     np.save(os.path.join(out_dir, name[i]+'_pred.npy'), pred_xyz.detach().cpu().numpy())

            pred_pose_eval[i:i + 1, :m_length[i], :] = pred_pose

            # if i < min(4, bs):
            #     draw_org.append(pose_xyz)
            #     draw_pred.append(pred_xyz)
            #     draw_text.append(caption[i])

        et_pred, em_pred = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, pred_pose_eval,
                                                          m_length)

        motion_pred_list.append(em_pred)
        motion_annotation_list.append(em)

        temp_R, temp_match = calculate_R_precision(et.cpu().numpy(), em.cpu().numpy(), top_k=3, sum_all=True)
        R_precision_real += temp_R
        matching_score_real += temp_match
        temp_R, temp_match = calculate_R_precision(et_pred.cpu().numpy(), em_pred.cpu().numpy(), top_k=3, sum_all=True)
        R_precision += temp_R
        matching_score_pred += temp_match

        nb_sample += bs

    motion_annotation_np = torch.cat(motion_annotation_list, dim=0).cpu().numpy()
    motion_pred_np = torch.cat(motion_pred_list, dim=0).cpu().numpy()
    gt_mu, gt_cov = calculate_activation_statistics(motion_annotation_np)
    mu, cov = calculate_activation_statistics(motion_pred_np)

    diversity_real = calculate_diversity(motion_annotation_np, 300 if nb_sample > 300 else 100)
    diversity = calculate_diversity(motion_pred_np, 300 if nb_sample > 300 else 100)

    R_precision_real = R_precision_real / nb_sample
    R_precision = R_precision / nb_sample

    matching_score_real = matching_score_real / nb_sample
    matching_score_pred = matching_score_pred / nb_sample

    fid = calculate_frechet_distance(gt_mu, gt_cov, mu, cov)

    msg = f"--> \t Eva. Iter {nb_iter} :, FID. {fid:.4f}, Diversity Real. {diversity_real:.4f}, Diversity. {diversity:.4f}, R_precision_real. {R_precision_real}, R_precision. {R_precision}, matching_score_real. {matching_score_real}, matching_score_pred. {matching_score_pred}"
    logger.info(msg)

    if draw:
        writer.add_scalar('./Test/FID', fid, nb_iter)
        writer.add_scalar('./Test/Diversity', diversity, nb_iter)
        writer.add_scalar('./Test/top1', R_precision[0], nb_iter)
        writer.add_scalar('./Test/top2', R_precision[1], nb_iter)
        writer.add_scalar('./Test/top3', R_precision[2], nb_iter)
        writer.add_scalar('./Test/matching_score', matching_score_pred, nb_iter)

        # if nb_iter % 5000 == 0 :
        #     for ii in range(4):
        #         tensorborad_add_video_xyz(writer, draw_org[ii], nb_iter, tag='./Vis/org_eval'+str(ii), nb_vis=1, title_batch=[draw_text[ii]], outname=[os.path.join(out_dir, 'gt'+str(ii)+'.gif')] if savegif else None)

        # if nb_iter % 5000 == 0 :
        #     for ii in range(4):
        #         tensorborad_add_video_xyz(writer, draw_pred[ii], nb_iter, tag='./Vis/pred_eval'+str(ii), nb_vis=1, title_batch=[draw_text[ii]], outname=[os.path.join(out_dir, 'pred'+str(ii)+'.gif')] if savegif else None)

    if fid < best_fid:
        msg = f"--> --> \t FID Improved from {best_fid:.5f} to {fid:.5f} !!!"
        logger.info(msg)
        best_fid, best_iter = fid, nb_iter
        # if save:
        #     torch.save({'net' : net.state_dict()}, os.path.join(out_dir, 'net_best_fid.pth'))

    if abs(diversity_real - diversity) < abs(diversity_real - best_div):
        msg = f"--> --> \t Diversity Improved from {best_div:.5f} to {diversity:.5f} !!!"
        logger.info(msg)
        best_div = diversity
        # if save:
        #     torch.save({'net' : net.state_dict()}, os.path.join(out_dir, 'net_best_div.pth'))

    if R_precision[0] > best_top1:
        msg = f"--> --> \t Top1 Improved from {best_top1:.4f} to {R_precision[0]:.4f} !!!"
        logger.info(msg)
        best_top1 = R_precision[0]
        # if save:
        #     torch.save({'net' : net.state_dict()}, os.path.join(out_dir, 'net_best_top1.pth'))

    if R_precision[1] > best_top2:
        msg = f"--> --> \t Top2 Improved from {best_top2:.4f} to {R_precision[1]:.4f} !!!"
        logger.info(msg)
        best_top2 = R_precision[1]

    if R_precision[2] > best_top3:
        msg = f"--> --> \t Top3 Improved from {best_top3:.4f} to {R_precision[2]:.4f} !!!"
        logger.info(msg)
        best_top3 = R_precision[2]

    if matching_score_pred < best_matching:
        msg = f"--> --> \t matching_score Improved from {best_matching:.5f} to {matching_score_pred:.5f} !!!"
        logger.info(msg)
        best_matching = matching_score_pred
        # if save:
        #     torch.save({'net' : net.state_dict()}, os.path.join(out_dir, 'net_best_matching.pth'))

    if save:
        torch.save({'net': net.state_dict()}, os.path.join(out_dir, 'net_last.pth'))

    net.train()
    return best_fid, best_iter, best_div, best_top1, best_top2, best_top3, best_matching, writer, logger


@torch.no_grad()
def evaluation_transformer(out_dir, val_loader, net, trans,mean,std, logger, writer, nb_iter, best_fid, best_iter, best_div,
                           best_top1, best_top2, best_top3, best_matching, clip_model, eval_wrapper, dataname='t2m',
                           draw=True, save=True, savegif=False, num_repeat=1, rand_pos=False, CFG=-1):
    log_file = ('/opt/data/private/myfile/momask_two/log/MMM/eval.txt')
    with open(log_file, 'a') as log:
        if num_repeat < 0:
            is_avg_all = True
            num_repeat = -num_repeat
        else:
            is_avg_all = False

        trans.eval()
        nb_sample = 0

        draw_org = []
        draw_pred = []
        draw_text = []
        draw_text_pred = []

        motion_annotation_list = []
        motion_pred_list = []
        motion_multimodality = []
        R_precision_real = 0
        R_precision = 0
        matching_score_real = 0
        matching_score_pred = 0

        nb_sample = 0
        blank_id = get_model(trans).num_vq
        for batch in tqdm(val_loader):
            name, text, motion1, motion2, motion_lens = batch

            bs, seq = motion1.shape[:2]

            clip_text = clip.tokenize(text, truncate=True).cuda()

            feat_clip_text, word_emb = clip_model(clip_text)

            motion_multimodality_batch = []
            m_tokens_len = torch.ceil((motion_lens) / 4)

            pred_len = motion_lens.cuda()
            pred_tok_len = m_tokens_len

            for i in range(num_repeat):
                motionpred1 = torch.zeros((bs, seq, motion1.shape[-1])).cuda()
                motionpred2 = torch.zeros((bs, seq, motion2.shape[-1])).cuda()
                # pred_len = torch.ones(bs).long()

                index_motion = trans(feat_clip_text, word_emb, type="sample", m_length=pred_len * 2, rand_pos=rand_pos,
                                     CFG=CFG)
                # [INFO] 1. this get the last index of blank_id
                # pred_length = (index_motion == blank_id).int().argmax(1).float()
                # [INFO] 2. this get the first index of blank_id
                pred_length = (index_motion >= blank_id).int()
                pred_length = torch.topk(pred_length, k=1, dim=1).indices.squeeze().float()
                # pred_length[pred_length==0] = index_motion.shape[1] # if blank_id in the first frame, set length to max
                # [INFO] need to run single sample at a time b/c it's conv
                index_motion1 = index_motion[:, 0::2]
                # 从 code_idx 中恢复 code_idx2
                index_motion2 = index_motion[:, 1::2]
                for k in range(bs):
                    ######### [INFO] Eval only the predicted length
                    #     if pred_length[k] == 0:
                    #         pred_len[k] = seq
                    #         continue
                    #     pred_pose = net(index_motion[k:k+1, :int(pred_length[k].item())], type='decode')
                    #     cur_len = pred_pose.shape[1]

                    #     pred_len[k] = min(cur_len, seq)
                    #     pred_pose_eval[k:k+1, :cur_len] = pred_pose[:, :seq]
                    # et_pred, em_pred = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, pred_pose_eval, pred_len)
                    ######################################################

                    ######### [INFO] Eval by m_length
                    pred_pose1 = net(index_motion1[k:k + 1, :int(pred_tok_len[k].item())], type='decode')
                    motionpred1[k:k + 1, :int(pred_len[k].item())] = pred_pose1
                    pred_pose2 = net(index_motion2[k:k + 1, :int(pred_tok_len[k].item())], type='decode')
                    motionpred2[k:k + 1, :int(pred_len[k].item())] = pred_pose2
                motionpred1 = motionpred1.cpu()
                motionpred2 = motionpred2.cpu()
                motionpred1 = motionpred1.numpy()
                motionpred2 = motionpred2.numpy()
                motionpred1 = (motionpred1 * std) + mean
                motionpred2 = (motionpred2 * std) + mean
                # motionpred1 = pad_sequences(motionpred1)
                # motionpred2 = pad_sequences(motionpred2)
                motionpred1 = torch.from_numpy(motionpred1).float()
                motionpred2 = torch.from_numpy(motionpred2).float()
                batch_pred = name, text, motionpred1, motionpred2, motion_lens
                et_pred, em_pred = eval_wrapper.get_co_embeddings(batch_pred)
                ######################################################

                motion_multimodality_batch.append(em_pred.reshape(bs, 1, -1))

                if i == 0 or is_avg_all:
                    motion1 = motion1.cpu()
                    motion2 = motion2.cpu()
                    motion1 = motion1.numpy()
                    motion2 = motion2.numpy()
                    motion1 = (motion1 * std) + mean
                    motion2 = (motion2 * std) + mean
                    motion1 = torch.from_numpy(motion1).float()
                    motion2 = torch.from_numpy(motion2).float()

                    batch = name, text, motion1, motion2, motion_lens
                    et, em = eval_wrapper.get_co_embeddings(batch)
                    motion_annotation_list.append(em)
                    motion_pred_list.append(em_pred)

                    # if draw:
                    #     pose = val_loader.dataset.inv_transform(pose.detach().cpu().numpy())
                    #     pose_xyz = recover_from_ric(torch.from_numpy(pose).float().cuda(), num_joints)

                    #     for j in range(min(4, bs)):
                    #         draw_org.append(pose_xyz[j][:m_length[j]].unsqueeze(0))
                    #         draw_text.append(clip_text[j])

                    temp_R = calculate_R_precision(et.cpu().numpy(), em.cpu().numpy(), top_k=3, sum_all=True)
                    R_precision_real += temp_R
                    temp_match = euclidean_distance_matrix(et.cpu().numpy(), em.cpu().numpy()).trace()
                    matching_score_real += temp_match
                    temp_R = calculate_R_precision(et_pred.cpu().numpy(), em_pred.cpu().numpy(), top_k=3,
                                                   sum_all=True)
                    temp_match = euclidean_distance_matrix(et_pred.cpu().numpy(), em_pred.cpu().numpy()).trace()
                    R_precision += temp_R
                    matching_score_pred += temp_match

                    nb_sample += bs
            motion_multimodality.append(torch.cat(motion_multimodality_batch, dim=1))

        motion_annotation_np = torch.cat(motion_annotation_list, dim=0).cpu().numpy()
        motion_pred_np = torch.cat(motion_pred_list, dim=0).cpu().numpy()
        gt_mu, gt_cov = calculate_activation_statistics(motion_annotation_np)
        mu, cov = calculate_activation_statistics(motion_pred_np)

        diversity_real = calculate_diversity(motion_annotation_np, 300 if nb_sample > 300 else 100)
        diversity = calculate_diversity(motion_pred_np, 300 if nb_sample > 300 else 100)

        R_precision_real = R_precision_real / nb_sample
        R_precision = R_precision / nb_sample

        matching_score_real = matching_score_real / nb_sample
        matching_score_pred = matching_score_pred / nb_sample

        multimodality = 0
        motion_multimodality = torch.cat(motion_multimodality, dim=0).cpu().numpy()
        if num_repeat > 1:
            multimodality = calculate_multimodality(motion_multimodality, 10)

        fid = calculate_frechet_distance(gt_mu, gt_cov, mu, cov)

        msg = f"--> \t Eva. Iter {nb_iter} :, \n\
                    FID. {fid:.4f} , \n\
                    Diversity Real. {diversity_real:.4f}, \n\
                    Diversity. {diversity:.4f}, \n\
                    R_precision_real. {R_precision_real}, \n\
                    R_precision. {R_precision}, \n\
                    matching_score_real. {matching_score_real}, \n\
                    matching_score_pred. {matching_score_pred}, \n\
                    multimodality. {multimodality:.4f}"
        log.write(msg + "\n")
        logger.info(msg)

        if draw:
            writer.add_scalar('./Test/FID', fid, nb_iter)
            writer.add_scalar('./Test/Diversity', diversity, nb_iter)
            writer.add_scalar('./Test/top1', R_precision[0], nb_iter)
            writer.add_scalar('./Test/top2', R_precision[1], nb_iter)
            writer.add_scalar('./Test/top3', R_precision[2], nb_iter)
            writer.add_scalar('./Test/matching_score', matching_score_pred, nb_iter)
            writer.add_scalar('./Test/multimodality', multimodality, nb_iter)

            # if nb_iter % 10000 == 0 :
            #     for ii in range(4):
            #         tensorborad_add_video_xyz(writer, draw_org[ii], nb_iter, tag='./Vis/org_eval'+str(ii), nb_vis=1, title_batch=[draw_text[ii]], outname=[os.path.join(out_dir, 'gt'+str(ii)+'.gif')] if savegif else None)
            # if nb_iter % 10000 == 0 :
            #     for ii in range(4):
            #         tensorborad_add_video_xyz(writer, draw_pred[ii], nb_iter, tag='./Vis/pred_eval'+str(ii), nb_vis=1, title_batch=[draw_text_pred[ii]], outname=[os.path.join(out_dir, 'pred'+str(ii)+'.gif')] if savegif else None)

        if fid < best_fid:
            msg = f"--> --> \t FID Improved from {best_fid:.5f} to {fid:.5f} !!!"
            log.write(msg + "\n")
            logger.info(msg)
            best_fid, best_iter = fid, nb_iter
            if save:
                torch.save({'trans': get_model(trans).state_dict()}, os.path.join(out_dir, 'net_best_fid.pth'))

        if matching_score_pred < best_matching:
            msg = f"--> --> \t matching_score Improved from {best_matching:.5f} to {matching_score_pred:.5f} !!!"
            log.write(msg + "\n")
            logger.info(msg)
            best_matching = matching_score_pred

        if abs(diversity_real - diversity) < abs(diversity_real - best_div):
            msg = f"--> --> \t Diversity Improved from {best_div:.5f} to {diversity:.5f} !!!"
            log.write(msg + "\n")
            logger.info(msg)
            best_div = diversity

        if R_precision[0] > best_top1:
            msg = f"--> --> \t Top1 Improved from {best_top1:.4f} to {R_precision[0]:.4f} !!!"
            log.write(msg + "\n")
            logger.info(msg)
            best_top1 = R_precision[0]

        if R_precision[1] > best_top2:
            msg = f"--> --> \t Top2 Improved from {best_top2:.4f} to {R_precision[1]:.4f} !!!"
            log.write(msg + "\n")
            logger.info(msg)
            best_top2 = R_precision[1]

        if R_precision[2] > best_top3:
            msg = f"--> --> \t Top3 Improved from {best_top3:.4f} to {R_precision[2]:.4f} !!!"
            log.write(msg + "\n")
            logger.info(msg)
            best_top3 = R_precision[2]

        if save:
            torch.save({'trans': get_model(trans).state_dict()}, os.path.join(out_dir, 'net_last.pth'))

        trans.train()
        return best_fid, best_iter, best_div, best_top1, best_top2, best_top3, best_matching, multimodality, writer, logger



def evaluation_transformer_uplow(out_dir, val_loader, net, trans, logger, writer, nb_iter, best_fid, best_iter,
                                 best_div, best_top1, best_top2, best_top3, best_matching, clip_model, eval_wrapper,
                                 dataname, draw=True, save=True, savegif=False, num_repeat=1, rand_pos=False, CFG=-1):
    from utils.humanml_utils import HML_UPPER_BODY_MASK, HML_LOWER_BODY_MASK

    trans.eval()
    nb_sample = 0

    draw_org = []
    draw_pred = []
    draw_text = []
    draw_text_pred = []

    motion_annotation_list = []
    motion_pred_list = []
    motion_multimodality = []
    R_precision_real = 0
    R_precision = 0
    matching_score_real = 0
    matching_score_pred = 0

    nb_sample = 0
    blank_id = get_model(trans).num_vq
    for batch in tqdm(val_loader):
        word_embeddings, pos_one_hots, clip_text, sent_len, pose, m_length, token, name = batch
        pose = pose.cuda().float()
        pose_lower = pose[..., HML_LOWER_BODY_MASK]
        bs, seq = pose.shape[:2]
        num_joints = 21 if pose.shape[-1] == 251 else 22

        text = clip.tokenize(clip_text, truncate=True).cuda()

        feat_clip_text, word_emb = clip_model(text)

        motion_multimodality_batch = []
        m_tokens_len = torch.ceil((m_length) / 4)

        pred_len = m_length.cuda()
        pred_tok_len = m_tokens_len

        max_motion_length = int(seq / 4) + 1
        mot_end_idx = get_model(net).vqvae.num_code
        mot_pad_idx = get_model(net).vqvae.num_code + 1
        target_lower = []
        for k in range(bs):
            target = net(pose[k:k + 1, :m_length[k]], type='encode')
            if m_tokens_len[k] + 1 < max_motion_length:
                target = torch.cat([target,
                                    torch.ones((1, 1, 2), dtype=int, device=target.device) * mot_end_idx,
                                    torch.ones((1, max_motion_length - 1 - m_tokens_len[k].int().item(), 2), dtype=int,
                                               device=target.device) * mot_pad_idx], axis=1)
            else:
                target = torch.cat([target,
                                    torch.ones((1, 1, 2), dtype=int, device=target.device) * mot_end_idx], axis=1)
            target_lower.append(target[..., 1])
        target_lower = torch.cat(target_lower, axis=0)

        for i in range(num_repeat):
            pred_pose_eval = torch.zeros((bs, seq, pose.shape[-1])).cuda()
            # pred_len = torch.ones(bs).long()

            index_motion = trans(feat_clip_text, target_lower, word_emb, type="sample", m_length=pred_len,
                                 rand_pos=rand_pos, CFG=CFG)
            # [INFO] 1. this get the last index of blank_id
            # pred_length = (index_motion == blank_id).int().argmax(1).float()
            # [INFO] 2. this get the first index of blank_id
            pred_length = (index_motion >= blank_id).int()
            pred_length = torch.topk(pred_length, k=1, dim=1).indices.squeeze().float()
            # pred_length[pred_length==0] = index_motion.shape[1] # if blank_id in the first frame, set length to max
            # [INFO] need to run single sample at a time b/c it's conv
            for k in range(bs):
                ######### [INFO] Eval only the predicted length
                #     if pred_length[k] == 0:
                #         pred_len[k] = seq
                #         continue
                #     pred_pose = net(index_motion[k:k+1, :int(pred_length[k].item())], type='decode')
                #     cur_len = pred_pose.shape[1]

                #     pred_len[k] = min(cur_len, seq)
                #     pred_pose_eval[k:k+1, :cur_len] = pred_pose[:, :seq]
                # et_pred, em_pred = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, pred_pose_eval, pred_len)
                ######################################################

                ######### [INFO] Eval by m_length
                all_tokens = torch.cat([
                    index_motion[k:k + 1, :int(pred_tok_len[k].item()), None],
                    target_lower[k:k + 1, :int(pred_tok_len[k].item()), None]
                ], axis=-1)
                pred_pose = net(all_tokens, type='decode')
                pred_pose_eval[k:k + 1, :int(pred_len[k].item())] = pred_pose
            pred_pose_eval[..., HML_LOWER_BODY_MASK] = pose_lower
            et_pred, em_pred = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, pred_pose_eval,
                                                              m_length)
            ######################################################

            motion_multimodality_batch.append(em_pred.reshape(bs, 1, -1))

            if i == 0:
                et, em = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, pose, m_length)
                motion_annotation_list.append(em)
                motion_pred_list.append(em_pred)

                # if draw:
                #     pose = val_loader.dataset.inv_transform(pose.detach().cpu().numpy())
                #     pose_xyz = recover_from_ric(torch.from_numpy(pose).float().cuda(), num_joints)

                #     for j in range(min(4, bs)):
                #         draw_org.append(pose_xyz[j][:m_length[j]].unsqueeze(0))
                #         draw_text.append(clip_text[j])

                temp_R, temp_match = calculate_R_precision(et.cpu().numpy(), em.cpu().numpy(), top_k=3, sum_all=True)
                R_precision_real += temp_R
                matching_score_real += temp_match
                temp_R, temp_match = calculate_R_precision(et_pred.cpu().numpy(), em_pred.cpu().numpy(), top_k=3,
                                                           sum_all=True)
                R_precision += temp_R
                matching_score_pred += temp_match

                nb_sample += bs
        motion_multimodality.append(torch.cat(motion_multimodality_batch, dim=1))

    motion_annotation_np = torch.cat(motion_annotation_list, dim=0).cpu().numpy()
    motion_pred_np = torch.cat(motion_pred_list, dim=0).cpu().numpy()
    gt_mu, gt_cov = calculate_activation_statistics(motion_annotation_np)
    mu, cov = calculate_activation_statistics(motion_pred_np)

    diversity_real = calculate_diversity(motion_annotation_np, 300 if nb_sample > 300 else 100)
    diversity = calculate_diversity(motion_pred_np, 300 if nb_sample > 300 else 100)

    R_precision_real = R_precision_real / nb_sample
    R_precision = R_precision / nb_sample

    matching_score_real = matching_score_real / nb_sample
    matching_score_pred = matching_score_pred / nb_sample

    multimodality = 0
    motion_multimodality = torch.cat(motion_multimodality, dim=0).cpu().numpy()
    if num_repeat > 1:
        multimodality = calculate_multimodality(motion_multimodality, 10)

    fid = calculate_frechet_distance(gt_mu, gt_cov, mu, cov)

    msg = f"--> \t Eva. Iter {nb_iter} :, \n\
                FID. {fid:.4f} , \n\
                Diversity Real. {diversity_real:.4f}, \n\
                Diversity. {diversity:.4f}, \n\
                R_precision_real. {R_precision_real}, \n\
                R_precision. {R_precision}, \n\
                matching_score_real. {matching_score_real}, \n\
                matching_score_pred. {matching_score_pred}, \n\
                multimodality. {multimodality:.4f}"
    logger.info(msg)

    if draw:
        writer.add_scalar('./Test/FID', fid, nb_iter)
        writer.add_scalar('./Test/Diversity', diversity, nb_iter)
        writer.add_scalar('./Test/top1', R_precision[0], nb_iter)
        writer.add_scalar('./Test/top2', R_precision[1], nb_iter)
        writer.add_scalar('./Test/top3', R_precision[2], nb_iter)
        writer.add_scalar('./Test/matching_score', matching_score_pred, nb_iter)
        writer.add_scalar('./Test/multimodality', multimodality, nb_iter)

        # if nb_iter % 10000 == 0 :
        #     for ii in range(4):
        #         tensorborad_add_video_xyz(writer, draw_org[ii], nb_iter, tag='./Vis/org_eval'+str(ii), nb_vis=1, title_batch=[draw_text[ii]], outname=[os.path.join(out_dir, 'gt'+str(ii)+'.gif')] if savegif else None)
        # if nb_iter % 10000 == 0 :
        #     for ii in range(4):
        #         tensorborad_add_video_xyz(writer, draw_pred[ii], nb_iter, tag='./Vis/pred_eval'+str(ii), nb_vis=1, title_batch=[draw_text_pred[ii]], outname=[os.path.join(out_dir, 'pred'+str(ii)+'.gif')] if savegif else None)

    if fid < best_fid:
        msg = f"--> --> \t FID Improved from {best_fid:.5f} to {fid:.5f} !!!"
        logger.info(msg)
        best_fid, best_iter = fid, nb_iter
        # if save:
        #     torch.save({'trans' : get_model(trans).state_dict()}, os.path.join(out_dir, 'net_best_fid.pth'))

    if matching_score_pred < best_matching:
        msg = f"--> --> \t matching_score Improved from {best_matching:.5f} to {matching_score_pred:.5f} !!!"
        logger.info(msg)
        best_matching = matching_score_pred

    if abs(diversity_real - diversity) < abs(diversity_real - best_div):
        msg = f"--> --> \t Diversity Improved from {best_div:.5f} to {diversity:.5f} !!!"
        logger.info(msg)
        best_div = diversity

    if R_precision[0] > best_top1:
        msg = f"--> --> \t Top1 Improved from {best_top1:.4f} to {R_precision[0]:.4f} !!!"
        logger.info(msg)
        best_top1 = R_precision[0]

    if R_precision[1] > best_top2:
        msg = f"--> --> \t Top2 Improved from {best_top2:.4f} to {R_precision[1]:.4f} !!!"
        logger.info(msg)
        best_top2 = R_precision[1]

    if R_precision[2] > best_top3:
        msg = f"--> --> \t Top3 Improved from {best_top3:.4f} to {R_precision[2]:.4f} !!!"
        logger.info(msg)
        best_top3 = R_precision[2]

    if save:
        torch.save({'trans': get_model(trans).state_dict()}, os.path.join(out_dir, 'net_last.pth'))

    trans.train()
    return pred_pose_eval, pose, m_length, clip_text, best_fid, best_iter, best_div, best_top1, best_top2, best_top3, best_matching, multimodality, writer, logger


@torch.no_grad()
def evaluation_transformer_test(out_dir, val_loader, net, trans, logger, writer, nb_iter, best_fid, best_iter, best_div,
                                best_top1, best_top2, best_top3, best_matching, best_multi, clip_model, eval_wrapper,
                                draw=True, save=True, savegif=False, savenpy=False):
    trans.eval()
    nb_sample = 0

    draw_org = []
    draw_pred = []
    draw_text = []
    draw_text_pred = []
    draw_name = []

    motion_annotation_list = []
    motion_pred_list = []
    motion_multimodality = []
    R_precision_real = 0
    R_precision = 0
    matching_score_real = 0
    matching_score_pred = 0

    nb_sample = 0

    for batch in val_loader:

        word_embeddings, pos_one_hots, clip_text, sent_len, pose, m_length, token, name = batch
        bs, seq = pose.shape[:2]
        num_joints = 21 if pose.shape[-1] == 251 else 22

        text = clip.tokenize(clip_text, truncate=True).cuda()

        feat_clip_text = clip_model.encode_text(text).float()
        motion_multimodality_batch = []
        for i in range(30):
            pred_pose_eval = torch.zeros((bs, seq, pose.shape[-1])).cuda()
            pred_len = torch.ones(bs).long()

            for k in range(bs):
                try:
                    index_motion = trans.sample(feat_clip_text[k:k + 1], True)
                except:
                    index_motion = torch.ones(1, 1).cuda().long()

                pred_pose = net.forward_decoder(index_motion)
                cur_len = pred_pose.shape[1]

                pred_len[k] = min(cur_len, seq)
                pred_pose_eval[k:k + 1, :cur_len] = pred_pose[:, :seq]

                if i == 0 and (draw or savenpy):
                    pred_denorm = val_loader.dataset.inv_transform(pred_pose.detach().cpu().numpy())
                    pred_xyz = recover_from_ric(torch.from_numpy(pred_denorm).float().cuda(), num_joints)

                    if savenpy:
                        np.save(os.path.join(out_dir, name[k] + '_pred.npy'), pred_xyz.detach().cpu().numpy())

                    if draw:
                        if i == 0:
                            draw_pred.append(pred_xyz)
                            draw_text_pred.append(clip_text[k])
                            draw_name.append(name[k])

            et_pred, em_pred = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, pred_pose_eval,
                                                              pred_len)

            motion_multimodality_batch.append(em_pred.reshape(bs, 1, -1))

            if i == 0:
                pose = pose.cuda().float()

                et, em = eval_wrapper.get_co_embeddings(word_embeddings, pos_one_hots, sent_len, pose, m_length)
                motion_annotation_list.append(em)
                motion_pred_list.append(em_pred)

                if draw or savenpy:
                    pose = val_loader.dataset.inv_transform(pose.detach().cpu().numpy())
                    pose_xyz = recover_from_ric(torch.from_numpy(pose).float().cuda(), num_joints)

                    if savenpy:
                        for j in range(bs):
                            np.save(os.path.join(out_dir, name[j] + '_gt.npy'),
                                    pose_xyz[j][:m_length[j]].unsqueeze(0).cpu().numpy())

                    if draw:
                        for j in range(bs):
                            draw_org.append(pose_xyz[j][:m_length[j]].unsqueeze(0))
                            draw_text.append(clip_text[j])

                temp_R, temp_match = calculate_R_precision(et.cpu().numpy(), em.cpu().numpy(), top_k=3, sum_all=True)
                R_precision_real += temp_R
                matching_score_real += temp_match
                temp_R, temp_match = calculate_R_precision(et_pred.cpu().numpy(), em_pred.cpu().numpy(), top_k=3,
                                                           sum_all=True)
                R_precision += temp_R
                matching_score_pred += temp_match

                nb_sample += bs

        motion_multimodality.append(torch.cat(motion_multimodality_batch, dim=1))

    motion_annotation_np = torch.cat(motion_annotation_list, dim=0).cpu().numpy()
    motion_pred_np = torch.cat(motion_pred_list, dim=0).cpu().numpy()
    gt_mu, gt_cov = calculate_activation_statistics(motion_annotation_np)
    mu, cov = calculate_activation_statistics(motion_pred_np)

    diversity_real = calculate_diversity(motion_annotation_np, 300 if nb_sample > 300 else 100)
    diversity = calculate_diversity(motion_pred_np, 300 if nb_sample > 300 else 100)

    R_precision_real = R_precision_real / nb_sample
    R_precision = R_precision / nb_sample

    matching_score_real = matching_score_real / nb_sample
    matching_score_pred = matching_score_pred / nb_sample

    multimodality = 0
    motion_multimodality = torch.cat(motion_multimodality, dim=0).cpu().numpy()
    multimodality = calculate_multimodality(motion_multimodality, 10)

    fid = calculate_frechet_distance(gt_mu, gt_cov, mu, cov)

    msg = f"--> \t Eva. Iter {nb_iter} :, FID. {fid:.4f}, Diversity Real. {diversity_real:.4f}, Diversity. {diversity:.4f}, R_precision_real. {R_precision_real}, R_precision. {R_precision}, matching_score_real. {matching_score_real}, matching_score_pred. {matching_score_pred}, multimodality. {multimodality:.4f}"
    logger.info(msg)

    if draw:
        for ii in range(len(draw_org)):
            tensorborad_add_video_xyz(writer, draw_org[ii], nb_iter, tag='./Vis/' + draw_name[ii] + '_org', nb_vis=1,
                                      title_batch=[draw_text[ii]], outname=[
                    os.path.join(out_dir, draw_name[ii] + '_skel_gt.gif')] if savegif else None)

            tensorborad_add_video_xyz(writer, draw_pred[ii], nb_iter, tag='./Vis/' + draw_name[ii] + '_pred', nb_vis=1,
                                      title_batch=[draw_text_pred[ii]], outname=[
                    os.path.join(out_dir, draw_name[ii] + '_skel_pred.gif')] if savegif else None)

    trans.train()
    return fid, best_iter, diversity, R_precision[0], R_precision[1], R_precision[
        2], matching_score_pred, multimodality, writer, logger


