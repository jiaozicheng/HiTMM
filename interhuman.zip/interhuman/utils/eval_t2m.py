import os
from tqdm import tqdm
import clip
import numpy as np
import torch
# from scipy import linalg
from utils.metrics import *
import torch.nn.functional as F

from utils.motion_process import recover_from_ric
#

def pad_sequences(gt_motion1, target_length=300):
    # 获取当前时间步长度
    b, t, l = gt_motion1.shape

    if t < target_length:
        # 计算需要填充的长度
        padding_len = target_length - t

        # 创建填充用的零矩阵
        padding_zeros = torch.zeros((b, padding_len, l))

        # 在时间步维度上对原始数据进行填充
        gt_motion1 = np.concatenate((gt_motion1, padding_zeros), axis=1)

    return gt_motion1
def normalize_nonzero_rows_iterative1(motion, mean, std):
    for i in range(motion.shape[0]):  # Loop over batches
        for j in range(motion.shape[1]):  # Loop over rows
            if np.any(motion[i, j] != 0):  # Check if the row is non-zero
                motion[i, j] = (motion[i, j] -mean) /std
    return motion
def normalize_nonzero_rows_iterative2(motion, mean, std):
    for i in range(motion.shape[0]):  # Loop over batches
        for j in range(motion.shape[1]):  # Loop over rows
            if np.any(motion[i, j] != 0):  # Check if the row is non-zero
                motion[i, j] = (motion[i, j] * std) + mean
    return motion
@torch.no_grad()
def evaluation_vqvae(out_dir, val_loader, net,log_file, writer, ep, best_fid, best_div, best_top1,
                     best_top2, best_top3, best_matching, eval_wrapper,plot_eval,mean,std, save=True, draw=True):
 # log_file = ('/opt/data/private/myfile/momask_two/log/vq/eval.txt')

 with open(log_file, 'a') as log:

    net.eval()
    device = torch.device('cuda:%d' % 0 if torch.cuda.is_available() else 'cpu')
    motion_annotation_list = []
    motion_pred_list = []

    R_precision_real = 0
    R_precision = 0

    nb_sample = 0
    matching_score_real = 0
    matching_score_pred = 0
    for idx, batch in tqdm(enumerate(val_loader)):
        # print(len(batch))

        name, text, motion1, motion2, motion_lens=batch

        motion1 = motion1.detach().to(device).float()
        motion2 = motion2.detach().to(device).float()

        # print("motion1")
        # print(motion1)
        bs, seq = motion1.shape[0], motion1.shape[1]

        motionpred1, loss_commit, perplexity = net(motion1)
        motionpred2, loss_commit, perplexity = net(motion2)



        motion1 = motion1.cpu()
        motion1 = motion1.numpy()
        motion1 = motion1 * std + mean
        motion1 = torch.from_numpy(motion1).float()

        motion2 = motion2.cpu()
        motion2 = motion2.numpy()
        motion2 = motion2 * std + mean
        motion2 = torch.from_numpy(motion2).float()

        # motions = torch.cat([motion1, motion2], dim=-1)


        motionpred1 = motionpred1.cpu()
        motionpred1 = motionpred1.numpy()
        motionpred1 = motionpred1 * std + mean
        motionpred1 = torch.from_numpy(motionpred1).float()


        motionpred2 = motionpred2.cpu()
        motionpred2 = motionpred2.numpy()
        motionpred2 = motionpred2 * std + mean
        motionpred2 = torch.from_numpy(motionpred2).float()





        pred_motions = torch.cat([motionpred1, motionpred2], dim=-1)






        batch=name, text, motion1, motion2, motion_lens
        et, em = eval_wrapper.get_co_embeddings(batch)


        batch_pred = name, text, motionpred1, motionpred2, (motion_lens//4)*4
        et_pred, em_pred = eval_wrapper.get_co_embeddings(batch_pred)

        motion_pred_list.append(em_pred)
        motion_annotation_list.append(em)

        temp_R = calculate_R_precision(et.cpu().numpy(), em.cpu().numpy(), top_k=3, sum_all=True)
        temp_match = euclidean_distance_matrix(et.cpu().numpy(), em.cpu().numpy()).trace()
        R_precision_real += temp_R
        matching_score_real += temp_match
        temp_R = calculate_R_precision(et_pred.cpu().numpy(), em_pred.cpu().numpy(), top_k=3, sum_all=True)
        temp_match = euclidean_distance_matrix(et_pred.cpu().numpy(), em_pred.cpu().numpy()).trace()
        R_precision += temp_R
        matching_score_pred += temp_match

        nb_sample += bs

    motion_annotation_np = torch.cat(motion_annotation_list, dim=0).cpu().numpy()
    motion_pred_np = torch.cat(motion_pred_list, dim=0).cpu().numpy()
    gt_mu, gt_cov = calculate_activation_statistics(motion_annotation_np)
    mu, cov = calculate_activation_statistics(motion_pred_np)

    diversity_real = calculate_diversity(motion_annotation_np, 300 if nb_sample > 300 else 100)
    diversity = calculate_diversity(motion_pred_np, 300 if nb_sample > 300 else 100)

    R_precision_real = R_precision_real / nb_sample
    R_precision = R_precision / nb_sample

    matching_score_real = matching_score_real / nb_sample
    matching_score_pred = matching_score_pred / nb_sample

    fid = calculate_frechet_distance(gt_mu, gt_cov, mu, cov)

    msg = "--> \t Eva. Ep %d:, FID. %.4f, Diversity Real. %.4f, Diversity. %.4f, R_precision_real. (%.4f, %.4f, %.4f), R_precision. (%.4f, %.4f, %.4f), matching_score_real. %.4f, matching_score_pred. %.4f"%\
          (ep, fid, diversity_real, diversity, R_precision_real[0],R_precision_real[1], R_precision_real[2],
           R_precision[0],R_precision[1], R_precision[2], matching_score_real, matching_score_pred )
    # logger.info(msg)
    log.write(msg + "\n")
    print(msg)

    if draw:
        writer.add_scalar('./Test/FID', fid, ep)
        writer.add_scalar('./Test/Diversity', diversity, ep)
        writer.add_scalar('./Test/top1', R_precision[0], ep)
        writer.add_scalar('./Test/top2', R_precision[1], ep)
        writer.add_scalar('./Test/top3', R_precision[2], ep)
        writer.add_scalar('./Test/matching_score', matching_score_pred, ep)

    if fid < best_fid:
        msg = "--> --> \t FID Improved from %.5f to %.5f !!!" % (best_fid, fid)
        log.write(msg + "\n")
        if draw: print(msg)
        best_fid = fid
        if save:
            torch.save({'vq_model': net.state_dict(), 'ep': ep}, os.path.join(out_dir, 'net_best_fid.tar'))



    if abs(diversity_real - diversity) < abs(diversity_real - best_div):
        msg = "--> --> \t Diversity Improved from %.5f to %.5f !!!"%(best_div, diversity)
        log.write(msg + "\n")
        if draw: print(msg)
        best_div = diversity
        # if save:
        #     torch.save({'vq_model': net.state_dict(), 'ep': ep}, os.path.join(out_dir, 'net_best_di.tar'))

    if R_precision[0] > best_top1:
        msg = "--> --> \t Top1 Improved from %.5f to %.5f !!!" % (best_top1, R_precision[0])
        log.write(msg + "\n")
        if draw: print(msg)
        best_top1 = R_precision[0]
        if save:
            torch.save({'vq_model': net.state_dict(), 'ep': ep}, os.path.join(out_dir, 'net_R1.tar'))
        # if save:
        #     torch.save({'vq_model': net.state_dict(), 'ep':ep}, os.path.join(out_dir, 'net_best_top1.tar'))

    if R_precision[1] > best_top2:
        msg = "--> --> \t Top2 Improved from %.5f to %.5f!!!" % (best_top2, R_precision[1])
        log.write(msg + "\n")
        if draw: print(msg)
        best_top2 = R_precision[1]
        if save:
            torch.save({'vq_model': net.state_dict(), 'ep': ep}, os.path.join(out_dir, 'net_R2.tar'))

    if R_precision[2] > best_top3:
        msg = "--> --> \t Top3 Improved from %.5f to %.5f !!!" % (best_top3, R_precision[2])
        log.write(msg + "\n")
        if draw: print(msg)
        best_top3 = R_precision[2]
        if save:
            torch.save({'vq_model': net.state_dict(), 'ep': ep}, os.path.join(out_dir, 'net_R3.tar'))

    if matching_score_pred < best_matching:
        msg = f"--> --> \t matching_score Improved from %.5f to %.5f !!!" % (best_matching, matching_score_pred)
        log.write(msg + "\n")
        if draw: print(msg)
        best_matching = matching_score_pred
        if save:
            torch.save({'vq_model': net.state_dict(), 'ep': ep}, os.path.join(out_dir, 'net_best_mm.tar'))









    return best_fid, best_div, best_top1, best_top2, best_top3, best_matching, writer







@torch.no_grad()
def evaluation_mask_transformer(out_dir, val_loader, trans, vq_model,log_file, writer, ep, best_fid, best_div,
                           best_top1, best_top2, best_top3, best_matching, eval_wrapper, plot_eval,mean,std,
                           save_ckpt=False, save_anim=False):
 device = torch.device('cuda:%d' % 0 if torch.cuda.is_available() else 'cpu')
 # log_file = ('/opt/data/private/myfile/momask_two/log/t2m/eval.txt')
 with open(log_file, 'a') as log:
    def save(file_name, ep):
        t2m_trans_state_dict = trans.state_dict()
        clip_weights = [e for e in t2m_trans_state_dict.keys() if e.startswith('clip_model.')]
        for e in clip_weights:
            del t2m_trans_state_dict[e]
        state = {
            't2m_transformer': t2m_trans_state_dict,
            # 'opt_t2m_transformer': self.opt_t2m_transformer.state_dict(),
            # 'scheduler':self.scheduler.state_dict(),
            'ep': ep,
        }
        torch.save(state, file_name)

    trans.eval()
    vq_model.eval()

    motion_annotation_list = []
    motion_pred_list = []
    R_precision_real = 0
    R_precision = 0
    matching_score_real = 0
    matching_score_pred = 0
    time_steps = 12
    if "kit" in out_dir:
        cond_scale = 4
    else:
        cond_scale = 3



    nb_sample = 0
    # for i in range(1):
    for batch in val_loader:
        # et, em = eval_wrapper.get_co_embeddings(batch)
        name, text, motion1, motion2, motion_lens= batch
        motion1 = motion1.detach().to(device).float()
        motion2 = motion2.detach().to(device).float()
        bs, seq = motion1.shape[0], motion1.shape[1]
        motion_lens = motion_lens.cuda()
        mids = trans.generate(text,(motion_lens // 4)*2, time_steps, cond_scale, temperature=1)


        mids1 = mids[..., 0::2]
        mids2 = mids[..., 1::2]




        mids1 = mids1.unsqueeze_(-1)
        mids2 = mids2.unsqueeze_(-1)





        motionpred1 = vq_model.forward_decoder(mids1)
        motionpred2 = vq_model.forward_decoder(mids2)








        motion1 = motion1.cpu()
        motion2 = motion2.cpu()
        motion1 = motion1.numpy()
        motion2 = motion2.numpy()
        motion1 = (motion1*std)+mean
        motion2 = (motion2*std)+mean
        motion1 = torch.from_numpy(motion1).float()
        motion2 = torch.from_numpy(motion2).float()
        motions=torch.cat([motion1,motion2],dim=-1)
        batch = name, text, motion1, motion2, motion_lens
        et, em = eval_wrapper.get_co_embeddings(batch)

        motionpred1 = motionpred1.cpu()
        motionpred2 = motionpred2.cpu()
        motionpred1 = motionpred1.numpy()
        motionpred2 = motionpred2.numpy()
        motionpred1 = (motionpred1*std)+mean
        motionpred2 = (motionpred2*std)+mean
        motionpred1 = torch.from_numpy(motionpred1).float()
        motionpred2 = torch.from_numpy(motionpred2).float()
        pred_motions = torch.cat([motionpred1, motionpred2], dim=-1)
        batch_pred = name, text, motionpred1, motionpred2, (motion_lens // 4)*4
        et_pred, em_pred = eval_wrapper.get_co_embeddings(batch_pred)

        # pred_motions=torch.cat([motionpred1,motionpred2],dim=-1)

        motion_annotation_list.append(em)
        motion_pred_list.append(em_pred)

        temp_R = calculate_R_precision(et.cpu().numpy(), em.cpu().numpy(), top_k=3, sum_all=True)
        temp_match = euclidean_distance_matrix(et.cpu().numpy(), em.cpu().numpy()).trace()
        R_precision_real += temp_R
        matching_score_real += temp_match
        temp_R = calculate_R_precision(et_pred.cpu().numpy(), em_pred.cpu().numpy(), top_k=3, sum_all=True)
        temp_match = euclidean_distance_matrix(et_pred.cpu().numpy(), em_pred.cpu().numpy()).trace()
        R_precision += temp_R
        matching_score_pred += temp_match

        nb_sample += bs

    motion_annotation_np = torch.cat(motion_annotation_list, dim=0).cpu().numpy()
    motion_pred_np = torch.cat(motion_pred_list, dim=0).cpu().numpy()
    gt_mu, gt_cov = calculate_activation_statistics(motion_annotation_np)
    mu, cov = calculate_activation_statistics(motion_pred_np)

    diversity_real = calculate_diversity(motion_annotation_np, 300 if nb_sample > 300 else 100)
    diversity = calculate_diversity(motion_pred_np, 300 if nb_sample > 300 else 100)

    R_precision_real = R_precision_real / nb_sample
    R_precision = R_precision / nb_sample

    matching_score_real = matching_score_real / nb_sample
    matching_score_pred = matching_score_pred / nb_sample

    fid = calculate_frechet_distance(gt_mu, gt_cov, mu, cov)

    msg = f"--> \t Eva. Ep {ep} :, FID. {fid:.4f}, Diversity Real. {diversity_real:.4f}, Diversity. {diversity:.4f}, R_precision_real. {R_precision_real}, R_precision. {R_precision}, matching_score_real. {matching_score_real}, matching_score_pred. {matching_score_pred}"
    log.write(msg + "\n")
    print(msg)

    # if draw:
    writer.add_scalar('./Test/FID', fid, ep)
    writer.add_scalar('./Test/Diversity', diversity, ep)
    writer.add_scalar('./Test/top1', R_precision[0], ep)
    writer.add_scalar('./Test/top2', R_precision[1], ep)
    writer.add_scalar('./Test/top3', R_precision[2], ep)
    writer.add_scalar('./Test/matching_score', matching_score_pred, ep)


    if fid < best_fid:
        msg = f"--> --> \t FID Improved from {best_fid:.5f} to {fid:.5f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_fid, best_ep = fid, ep
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_fid.tar'), ep)

    if matching_score_pred < best_matching:
        msg = f"--> --> \t matching_score Improved from {best_matching:.5f} to {matching_score_pred:.5f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_matching = matching_score_pred
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_mm.tar'), ep)

    if abs(diversity_real - diversity) < abs(diversity_real - best_div):
        msg = f"--> --> \t Diversity Improved from {best_div:.5f} to {diversity:.5f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_div = diversity

    if R_precision[0] > best_top1:
        msg = f"--> --> \t Top1 Improved from {best_top1:.4f} to {R_precision[0]:.4f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_top1 = R_precision[0]
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_R1.tar'), ep)

    if R_precision[1] > best_top2:
        msg = f"--> --> \t Top2 Improved from {best_top2:.4f} to {R_precision[1]:.4f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_top2 = R_precision[1]
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_R2.tar'), ep)

    if R_precision[2] > best_top3:
        msg = f"--> --> \t Top3 Improved from {best_top3:.4f} to {R_precision[2]:.4f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_top3 = R_precision[2]
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_R3.tar'), ep)


    return best_fid, best_div, best_top1, best_top2, best_top3, best_matching, writer


@torch.no_grad()
def evaluation_res_transformer(out_dir, val_loader, trans, vq_model,log_file, writer, ep, best_fid, best_div,
                           best_top1, best_top2, best_top3, best_matching, eval_wrapper, plot_eval,mean,std,
                           save_ckpt=False, save_anim=False, cond_scale=2, temperature=1):


 with open(log_file, 'a') as log:
    def save(file_name, ep):
        res_trans_state_dict = trans.state_dict()
        clip_weights = [e for e in res_trans_state_dict.keys() if e.startswith('clip_model.')]
        for e in clip_weights:
            del res_trans_state_dict[e]
        state = {
            'res_transformer': res_trans_state_dict,
            # 'opt_t2m_transformer': self.opt_t2m_transformer.state_dict(),
            # 'scheduler':self.scheduler.state_dict(),
            'ep': ep,
        }
        torch.save(state, file_name)

    trans.eval()
    vq_model.eval()

    motion_annotation_list = []
    motion_pred_list = []
    R_precision_real = 0
    R_precision = 0
    matching_score_real = 0
    matching_score_pred = 0

    # print(num_quantizer)
    # assert num_quantizer >= len(time_steps) and num_quantizer >= len(cond_scales)

    nb_sample = 0
    # for i in range(1):
    for batch in val_loader:
        # et, em = eval_wrapper.get_co_embeddings(batch)

        name, text, motion1, motion2, motion_lens  = batch
        motion_lens = motion_lens.cuda().long()
        motion1 = motion1.cuda().float()
        motion2 = motion2.cuda().float()
        bs, seq = motion1.shape[:2]

        code_idx1, all_codes1 = vq_model.encode(motion1)
        code_idx2, all_codes2 = vq_model.encode(motion2)


        b, n, l = code_idx1.shape
        # 创建一个新的数组，其形状是 (b, 2 * n, l)
        code_idx = torch.zeros((b, 2 * n, l), dtype=code_idx1.dtype).cuda()

        # 使用切片操作将 code_idx1 和 code_idx2 插入到奇数列和偶数列
        code_idx[:, 0::2] = code_idx1  # 奇数列
        code_idx[:, 1::2] = code_idx2  # 偶数列


        if ep == 0:
            mids = code_idx[..., 0:1]
        else:
            mids = trans.generate(code_idx[..., 0], text,(motion_lens // 4)*2,
                                      temperature=temperature, cond_scale=cond_scale)


        bs, seq,l = mids.shape[0], mids.shape[1],mids.shape[2]



        mids1=  mids[:,0::2, :]
        mids2 = mids[:,1::2, :]




        motionpred1 = vq_model.forward_decoder(mids1)
        motionpred2 = vq_model.forward_decoder(mids2)





        motion1 = motion1.cpu()
        motion2 = motion2.cpu()
        motion1 = motion1.numpy()
        motion2 = motion2.numpy()
        motion1 = (motion1 * std) + mean
        motion2 = (motion2 * std) + mean
        motion1 = torch.from_numpy(motion1).float()
        motion2 = torch.from_numpy(motion2).float()
        motions = torch.cat([motion1,motion2],dim=-1)
        batch = name, text, motion1, motion2, motion_lens
        et, em = eval_wrapper.get_co_embeddings(batch)


        motionpred1 = motionpred1.cpu()
        motionpred2 = motionpred2.cpu()
        motionpred1 = motionpred1.numpy()
        motionpred2 = motionpred2.numpy()
        motionpred1 = (motionpred1 * std) + mean
        motionpred2 = (motionpred2 * std) + mean
        motionpred1 = torch.from_numpy(motionpred1).float()
        motionpred2 = torch.from_numpy(motionpred2).float()
        pred_motions=torch.cat([motionpred1,motionpred2],dim=-1)
        batch_pred = name, text, motionpred1, motionpred2, (motion_lens//4)*4

        et_pred, em_pred = eval_wrapper.get_co_embeddings(batch_pred)


        motion_annotation_list.append(em)
        motion_pred_list.append(em_pred)

        temp_R = calculate_R_precision(et.cpu().numpy(), em.cpu().numpy(), top_k=3, sum_all=True)
        temp_match = euclidean_distance_matrix(et.cpu().numpy(), em.cpu().numpy()).trace()
        R_precision_real += temp_R
        matching_score_real += temp_match
        temp_R = calculate_R_precision(et_pred.cpu().numpy(), em_pred.cpu().numpy(), top_k=3, sum_all=True)
        temp_match = euclidean_distance_matrix(et_pred.cpu().numpy(), em_pred.cpu().numpy()).trace()
        R_precision += temp_R
        matching_score_pred += temp_match

        nb_sample += bs

    motion_annotation_np = torch.cat(motion_annotation_list, dim=0).cpu().numpy()
    motion_pred_np = torch.cat(motion_pred_list, dim=0).cpu().numpy()
    gt_mu, gt_cov = calculate_activation_statistics(motion_annotation_np)
    mu, cov = calculate_activation_statistics(motion_pred_np)

    diversity_real = calculate_diversity(motion_annotation_np, 300 if nb_sample > 300 else 100)
    diversity = calculate_diversity(motion_pred_np, 300 if nb_sample > 300 else 100)

    R_precision_real = R_precision_real / nb_sample
    R_precision = R_precision / nb_sample

    matching_score_real = matching_score_real / nb_sample
    matching_score_pred = matching_score_pred / nb_sample

    fid = calculate_frechet_distance(gt_mu, gt_cov, mu, cov)

    msg = f"--> \t Eva. Ep {ep} :, FID. {fid:.4f}, Diversity Real. {diversity_real:.4f}, Diversity. {diversity:.4f}, R_precision_real. {R_precision_real}, R_precision. {R_precision}, matching_score_real. {matching_score_real}, matching_score_pred. {matching_score_pred}"
    log.write(msg + "\n")
    print(msg)

    # if draw:
    writer.add_scalar('./Test/FID', fid, ep)
    writer.add_scalar('./Test/Diversity', diversity, ep)
    writer.add_scalar('./Test/top1', R_precision[0], ep)
    writer.add_scalar('./Test/top2', R_precision[1], ep)
    writer.add_scalar('./Test/top3', R_precision[2], ep)
    writer.add_scalar('./Test/matching_score', matching_score_pred, ep)


    if fid < best_fid:
        msg = f"--> --> \t FID Improved from {best_fid:.5f} to {fid:.5f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_fid, best_ep = fid, ep
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_fid.tar'), ep)


    if matching_score_pred < best_matching:
        msg = f"--> --> \t matching_score Improved from {best_matching:.5f} to {matching_score_pred:.5f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_matching = matching_score_pred
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_mm.tar'), ep)

    if abs(diversity_real - diversity) < abs(diversity_real - best_div):
        msg = f"--> --> \t Diversity Improved from {best_div:.5f} to {diversity:.5f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_div = diversity

    if R_precision[0] > best_top1:
        msg = f"--> --> \t Top1 Improved from {best_top1:.4f} to {R_precision[0]:.4f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_top1 = R_precision[0]
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_R1.tar'), ep)

    if R_precision[1] > best_top2:
        msg = f"--> --> \t Top2 Improved from {best_top2:.4f} to {R_precision[1]:.4f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_top2 = R_precision[1]
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_R2.tar'), ep)

    if R_precision[2] > best_top3:
        msg = f"--> --> \t Top3 Improved from {best_top3:.4f} to {R_precision[2]:.4f} !!!"
        log.write(msg + "\n")
        print(msg)
        best_top3 = R_precision[2]
        if save_ckpt:
            save(os.path.join(out_dir, 'model', 'net_best_R3.tar'), ep)


    return best_fid, best_div, best_top1, best_top2, best_top3, best_matching, writer


