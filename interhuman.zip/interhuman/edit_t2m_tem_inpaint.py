import os
from os.path import join as pjoin

import torch
import torch.nn.functional as F

from models.mask_transformer.cross_transformer import MaskTransformer
from models.mask_transformer.transformer import ResidualTransformer
from models.vq.model import RVQVAE, LengthEstimator

from options.eval_option import EvalT2MOptions
from utils.get_opt import get_opt

from utils.fixseed import fixseed
from visualization.joints2bvh import Joint2BVHConvertor

from utils.motion_process import recover_from_ric
from utils.plot_script import plot_3d_motion

from utils.paramUtil import t2m_kinematic_chain
clip_version = 'ViT-L/14@336px'

import numpy as np

from gen_t2m import load_vq_model, load_res_model, load_trans_model

def load_vq_model(vq_opt):
    # opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.vq_name, 'opt.txt')
    vq_model = RVQVAE(vq_opt,
                dim_pose,
                vq_opt.nb_code,
                vq_opt.code_dim,
                vq_opt.output_emb_width,
                vq_opt.down_t,
                vq_opt.stride_t,
                vq_opt.width,
                vq_opt.depth,
                vq_opt.dilation_growth_rate,
                vq_opt.vq_act,
                vq_opt.vq_norm)
    ckpt = torch.load('/interhuman/checkpoints/t2m/rvq_name/model/final_fid.tar',
                            map_location=opt.device)
    model_key = 'vq_model' if 'vq_model' in ckpt else 'net'
    vq_model.load_state_dict(ckpt[model_key])
    print(f'Loading VQ Model {vq_opt.name} Completed!')
    return vq_model, vq_opt

def load_trans_model(model_opt, which_model):
    t2m_transformer = MaskTransformer(code_dim=model_opt.code_dim,
                                      cond_mode='text',
                                      latent_dim=model_opt.latent_dim,
                                      ff_size=model_opt.ff_size,
                                      num_layers=model_opt.n_layers,
                                      num_heads=model_opt.n_heads,
                                      dropout=model_opt.dropout,
                                      clip_dim=768,
                                      cond_drop_prob=model_opt.cond_drop_prob,
                                      clip_version=clip_version,
                                      opt=model_opt)
    ckpt = torch.load('/interhuman/checkpoints/t2m/mtrans_name/model/net_best_R3.tar',
                      map_location=opt.device)
    model_key = 't2m_transformer' if 't2m_transformer' in ckpt else 'trans'
    # print(ckpt.keys())
    missing_keys, unexpected_keys = t2m_transformer.load_state_dict(ckpt[model_key], strict=False)
    assert len(unexpected_keys) == 0
    assert all([k.startswith('clip_model.') for k in missing_keys])
    print(f'Loading Mask Transformer {opt.name} from epoch {ckpt["ep"]}!')
    return t2m_transformer

def load_res_model(res_opt):
    res_opt.num_quantizers = vq_opt.num_quantizers
    res_opt.num_tokens = vq_opt.nb_code
    res_transformer = ResidualTransformer(code_dim=vq_opt.code_dim,
                                            cond_mode='text',
                                            latent_dim=res_opt.latent_dim,
                                            ff_size=res_opt.ff_size,
                                            num_layers=res_opt.n_layers,
                                            num_heads=res_opt.n_heads,
                                            dropout=res_opt.dropout,
                                            clip_dim=768,
                                            shared_codebook=vq_opt.shared_codebook,
                                            cond_drop_prob=res_opt.cond_drop_prob,
                                            # codebook=vq_model.quantizer.codebooks[0] if opt.fix_token_emb else None,
                                            share_weight=res_opt.share_weight,
                                            clip_version=clip_version,
                                            opt=res_opt)

    ckpt = torch.load('/interhuman/checkpoints/t2m/rtrans_name/model/net_best_fid.tar',
                      map_location=opt.device)
    missing_keys, unexpected_keys = res_transformer.load_state_dict(ckpt['res_transformer'], strict=False)
    assert len(unexpected_keys) == 0
    assert all([k.startswith('clip_model.') for k in missing_keys])
    print(f'Loading Residual Transformer {res_opt.name} from epoch {ckpt["ep"]}!')
    return res_transformer
def plot_t2m( mp_data, result_path, caption):
    mp_joint = []
    for i, data in enumerate(mp_data):
        if i == 0:
            joint = data[:, :22 * 3].reshape(-1, 22, 3)
        else:
            joint = data[:, :22 * 3].reshape(-1, 22, 3)

        mp_joint.append(joint)

    plot_3d_motion(result_path, t2m_kinematic_chain, mp_joint, title=caption, fps=30)
if __name__ == '__main__':
    parser = EvalT2MOptions()
    opt = parser.parse()
    fixseed(opt.seed)

    opt.device = torch.device("cpu" if opt.gpu_id == -1 else "cuda:" + str(opt.gpu_id))
    torch.autograd.set_detect_anomaly(True)

    dim_pose = 336 if opt.dataset_name == 'interx' else 262

    root_dir = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.name)
    model_dir = pjoin(root_dir, 'model')
    result_dir = pjoin('./editing', opt.ext)
    joints_dir = pjoin(result_dir, 'joints')
    animation_dir = pjoin(result_dir, 'animations')
    os.makedirs(joints_dir, exist_ok=True)
    os.makedirs(animation_dir,exist_ok=True)

    model_opt_path = pjoin(root_dir, 'opt.txt')
    model_opt = get_opt(model_opt_path, device=opt.device)

    #######################
    ######Loading RVQ######
    #######################
    vq_opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, model_opt.vq_name, 'opt.txt')
    vq_opt = get_opt(vq_opt_path, device=opt.device)
    vq_opt.dim_pose = dim_pose
    vq_model, vq_opt = load_vq_model(vq_opt)

    model_opt.num_tokens = vq_opt.nb_code
    model_opt.num_quantizers = vq_opt.num_quantizers
    model_opt.code_dim = vq_opt.code_dim

    #################################
    ######Loading R-Transformer######
    #################################
    res_opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.res_name, 'opt.txt')
    res_opt = get_opt(res_opt_path, device=opt.device)
    res_model = load_res_model(res_opt)

    assert res_opt.vq_name == model_opt.vq_name

    #################################
    ######Loading M-Transformer######
    #################################
    t2m_transformer = load_trans_model(model_opt, 'latest.tar')

    t2m_transformer.eval()
    vq_model.eval()
    res_model.eval()

    res_model.to(opt.device)
    t2m_transformer.to(opt.device)
    vq_model.to(opt.device)

    ##### ---- Data ---- #####
    max_motion_length = 300
    data_root = '/interhuman/dataset/intergentwoperson'
    mean = np.load(pjoin(data_root, 'global_mean.npy'))
    std = np.load(pjoin(data_root, 'global_std.npy'))
    def inv_transform(data):
        return data * std + mean
    ### We provided an example source motion (from 'new_joint_vecs') for editing. See './example_data/000612.mp4'###
    motion1 = np.load(opt.source_motion1)
    motion2 = np.load(opt.source_motion2)
    m_length = len(motion1)
    motion1 = (motion1 - mean) / std
    motion2 = (motion2 - mean) / std
    # if max_motion_length > m_length:
    #     motion1 = np.concatenate([motion1, np.zeros((max_motion_length - m_length, motion1.shape[1])) ], axis=0)
    #     motion2 = np.concatenate([motion2, np.zeros((max_motion_length - m_length, motion2.shape[1]))], axis=0)
    motion1 = torch.from_numpy(motion1).to(opt.device)
    motion2 = torch.from_numpy(motion2).to(opt.device)

    prompt_list = []
    length_list = []
    if opt.motion_length == 0:
        opt.motion_length = m_length
        print("Using default motion length.")
    
    prompt_list.append(opt.text_prompt)
    length_list.append(opt.motion_length)
    if opt.text_prompt == "":
        raise "Using an empty text prompt."

    token_lens = torch.LongTensor(length_list) // 4
    token_lens = token_lens.to(opt.device).long()

    m_length = token_lens * 4
    captions = prompt_list
    print_captions = captions[0]

    _edit_slice = opt.mask_edit_section
    edit_slice = []
    for eds in _edit_slice:
        _start, _end = eds.split(',')
        _start = eval(_start)
        _end = eval(_end)
        edit_slice.append([_start, _end])

    sample = 0
    kinematic_chain = t2m_kinematic_chain
    converter = Joint2BVHConvertor()

    motion1 = motion1.unsqueeze(0)
    motion2 = motion2.unsqueeze(0)

    with torch.no_grad():
        token1, feature1 = vq_model.encode(motion1)
        token2, feature2 = vq_model.encode(motion2)

    b, n, l = token1.shape
    # 创建一个新的数组，其形状是 (b, 2 * n, l)
    tokens = torch.zeros((b, 2 * n, l), dtype=token1.dtype).to(token1.device)

    # 使用切片操作将 code_idx1 和 code_idx2 插入到奇数列和偶数列
    tokens[:, 0::2, :] = token1  # 奇数列
    tokens[:, 1::2, :] = token2  # 偶数列
    ### build editing mask, TOEDIT marked as 1 ###
    edit_mask = torch.zeros_like(tokens[..., 0])
    seq_len = tokens.shape[1]
    print('seq_len')
    print(seq_len)
    for _start, _end in edit_slice:
        if isinstance(_start, float):
            _start = int(_start*seq_len)
            _end = int(_end*seq_len)
        else:
            _start //= 4
            _end //= 4
        edit_mask[:, _start: _end] = 1
        print_captions = f'{print_captions} [{_start*4/20.}s - {_end*4/20.}s]'
    edit_mask = edit_mask.bool()
    for r in range(opt.repeat_times):
        print("-->Repeat %d"%r)
        with torch.no_grad():
            mids = t2m_transformer.edit(
                                        captions, tokens[..., 0].clone(), (m_length//4)*2,
                                        timesteps=opt.time_steps,
                                        cond_scale=opt.cond_scale,
                                        temperature=opt.temperature,
                                        topk_filter_thres=opt.topkr,
                                        gsample=opt.gumbel_sample,
                                        force_mask=opt.force_mask,
                                        edit_mask=edit_mask.clone(),
                                        )
            mids = res_model.generate(mids, captions, (m_length // 4) * 2, temperature=1, cond_scale=4)
            # if opt.use_res_model:
            #     mids = res_model.generate(mids, captions, (m_length//4)*2, temperature=1, cond_scale=4)
            # else:
            #     mids.unsqueeze_(-1)
            pred_ids1 = mids[:, 0::2, :]  # 提取奇数列
            pred_ids2 = mids[:, 1::2, :]

            pred_motion1 = vq_model.forward_decoder(pred_ids1)
            pred_motion2 = vq_model.forward_decoder(pred_ids2)

            pred_motion1 = pred_motion1.detach().cpu().numpy()
            pred_motion2 = pred_motion2.detach().cpu().numpy()

            pred_motion1 = inv_transform(pred_motion1)
            pred_motion2 = inv_transform(pred_motion2)

            motionpred1 = torch.from_numpy(pred_motion1).float()
            motionpred2 = torch.from_numpy(pred_motion2).float()

            data = torch.cat((motionpred1, motionpred2), dim=-1)  # 在最后一个维度上连接
            data = data.numpy()

            data = data[0]
            print('data.shape')
            print(data.shape)

            motion_output = [[], []]
            motion_output[0] = data[:, :66].reshape(-1, 22, 3)
            motion_output[1] = data[:, 262:328].reshape(-1, 22, 3)
            for index, joint_data in enumerate(motion_output):
                folder_path = f"edit_results/{captions}/npy{r}"
                # 如果文件夹不存在，则创建
                os.makedirs(folder_path, exist_ok=True)
                # 生成文件名
                filename = os.path.join(folder_path, f"person{index}.npy")
                # 保存文件
                np.save(filename, joint_data)
            result_folder = f"edit_results/{captions}/npy{r}"
            os.makedirs(result_folder, exist_ok=True)

            # 生成可视化结果的路径
            result_path = os.path.join(result_folder, "vis.mp4")
            plot_t2m([motion_output[0], motion_output[1]],
                     result_path,
                     "")


