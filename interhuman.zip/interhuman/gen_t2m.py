import os
from os.path import join as pjoin

import torch
import torch.nn.functional as F

from models.mask_transformer.cross_transformer import MaskTransformer
from models.mask_transformer.transformer import ResidualTransformer
from models.vq.model import RVQVAE, LengthEstimator

from options.eval_option import EvalT2MOptions
from utils.get_opt import get_opt

from utils.fixseed import fixseed
from visualization.joints2bvh import Joint2BVHConvertor
from torch.distributions.categorical import Categorical


from utils.motion_process import recover_from_ric
from utils.plot_script import plot_3d_motion

from utils.paramUtil import t2m_kinematic_chain

import numpy as np
clip_version = 'ViT-L/14@336px'

def plot_t2m( mp_data, result_path, caption):
    mp_joint = []
    for i, data in enumerate(mp_data):
        if i == 0:
            joint = data[:, :22 * 3].reshape(-1, 22, 3)
        else:
            joint = data[:, :22 * 3].reshape(-1, 22, 3)

        mp_joint.append(joint)

    plot_3d_motion(result_path, t2m_kinematic_chain, mp_joint, title=caption, fps=30)
def load_vq_model(vq_opt):
    # opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.vq_name, 'opt.txt')
    vq_model = RVQVAE(vq_opt,
                dim_pose,
                vq_opt.nb_code,
                vq_opt.code_dim,
                vq_opt.output_emb_width,
                vq_opt.down_t,
                vq_opt.stride_t,
                vq_opt.width,
                vq_opt.depth,
                vq_opt.dilation_growth_rate,
                vq_opt.vq_act,
                vq_opt.vq_norm)
    ckpt = torch.load('interhuman/checkpoints/t2m/rvq_name/model/latest.tar',
                            map_location=opt.device)
    model_key = 'vq_model' if 'vq_model' in ckpt else 'net'
    vq_epoch = ckpt['ep'] if 'ep' in ckpt else -1
    vq_model.load_state_dict(ckpt[model_key])
    print(f'Loading VQ Model {opt.vq_name} Completed!, Epoch {vq_epoch}')
    return vq_model, vq_opt

def load_trans_model(model_opt):
    t2m_transformer = MaskTransformer(code_dim=model_opt.code_dim,
                                      cond_mode='text',
                                      latent_dim=model_opt.latent_dim,
                                      ff_size=model_opt.ff_size,
                                      num_layers=model_opt.n_layers,
                                      num_heads=model_opt.n_heads,
                                      dropout=model_opt.dropout,
                                      clip_dim=768,
                                      cond_drop_prob=model_opt.cond_drop_prob,
                                      clip_version=clip_version,
                                      opt=model_opt)
    ckpt = torch.load('interhuman/checkpoints/t2m/mtrans_name/model/net_best_R3.tar',
                      map_location=opt.device)
    model_key = 't2m_transformer' if 't2m_transformer' in ckpt else 'trans'
    # print(ckpt.keys())
    missing_keys, unexpected_keys = t2m_transformer.load_state_dict(ckpt[model_key], strict=False)
    assert len(unexpected_keys) == 0
    assert all([k.startswith('clip_model.') for k in missing_keys])
    print(f'Loading Mask Transformer {opt.name} from epoch {ckpt["ep"]}!')
    return t2m_transformer

def load_res_model(res_opt):
    res_opt.num_quantizers = vq_opt.num_quantizers
    res_opt.num_tokens = vq_opt.nb_code
    res_transformer = ResidualTransformer(code_dim=vq_opt.code_dim,
                                            cond_mode='text',
                                            latent_dim=res_opt.latent_dim,
                                            ff_size=res_opt.ff_size,
                                            num_layers=res_opt.n_layers,
                                            num_heads=res_opt.n_heads,
                                            dropout=res_opt.dropout,
                                            clip_dim=768,
                                            shared_codebook=vq_opt.shared_codebook,
                                            cond_drop_prob=res_opt.cond_drop_prob,
                                            # codebook=vq_model.quantizer.codebooks[0] if opt.fix_token_emb else None,
                                            share_weight=res_opt.share_weight,
                                            clip_version=clip_version,
                                            opt=res_opt)

    ckpt = torch.load('interhuman/checkpoints/t2m/rtrans_name/model/net_best_fid.tar',
                      map_location=opt.device)
    missing_keys, unexpected_keys = res_transformer.load_state_dict(ckpt['res_transformer'], strict=False)
    assert len(unexpected_keys) == 0
    assert all([k.startswith('clip_model.') for k in missing_keys])
    print(f'Loading Residual Transformer {res_opt.name} from epoch {ckpt["ep"]}!')
    return res_transformer

def load_len_estimator(opt):
    model = LengthEstimator(512, 50)
    ckpt = torch.load(pjoin(opt.checkpoints_dir, opt.dataset_name, 'length_estimator', 'model', 'finest.tar'),
                      map_location=opt.device)
    model.load_state_dict(ckpt['estimator'])
    print(f'Loading Length Estimator from epoch {ckpt["epoch"]}!')
    return model


if __name__ == '__main__':
    parser = EvalT2MOptions()
    opt = parser.parse()
    fixseed(opt.seed)

    opt.device = torch.device("cpu" if opt.gpu_id == -1 else "cuda:" + str(opt.gpu_id))
    torch.autograd.set_detect_anomaly(True)

    dim_pose = 251 if opt.dataset_name == 'kit' else 262

    # out_dir = pjoin(opt.check)
    root_dir = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.name)
    model_dir = pjoin(root_dir, 'model')
    result_dir = pjoin('./generation', opt.ext)
    joints_dir = pjoin(result_dir, 'joints')
    animation_dir = pjoin(result_dir, 'animations')
    os.makedirs(joints_dir, exist_ok=True)
    os.makedirs(animation_dir,exist_ok=True)

    model_opt_path = pjoin(root_dir, 'opt.txt')
    model_opt = get_opt(model_opt_path, device=opt.device)


    #######################
    ######Loading RVQ######
    #######################
    vq_opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, model_opt.vq_name, 'opt.txt')
    vq_opt = get_opt(vq_opt_path, device=opt.device)
    vq_opt.dim_pose = dim_pose
    vq_model, vq_opt = load_vq_model(vq_opt)

    model_opt.num_tokens = vq_opt.nb_code
    model_opt.num_quantizers = vq_opt.num_quantizers
    model_opt.code_dim = vq_opt.code_dim

    #################################
    ######Loading R-Transformer######
    #################################
    res_opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.res_name, 'opt.txt')
    res_opt = get_opt(res_opt_path, device=opt.device)
    res_model = load_res_model(res_opt)

    # assert res_opt.vq_name == model_opt.vq_name

    #################################
    ######Loading M-Transformer######
    #################################
    t2m_transformer = load_trans_model(model_opt)

    ##################################
    #####Loading Length Predictor#####
    ##################################
    # length_estimator = load_len_estimator(model_opt)

    t2m_transformer.eval()
    vq_model.eval()
    res_model.eval()
    # length_estimator.eval()

    res_model.to(opt.device)
    t2m_transformer.to(opt.device)
    vq_model.to(opt.device)
    # length_estimator.to(opt.device)

    ##### ---- Dataloader ---- #####
    opt.nb_joints = 21 if opt.dataset_name == 'kit' else 22

    data_root = 'interhuman/dataset/intergentwoperson'
    mean = np.load(pjoin(data_root, 'global_mean.npy'))
    std = np.load(pjoin(data_root, 'global_std.npy'))
    def inv_transform(data):
        return data * std + mean

    prompt_list = []
    length_list = []

    est_length = False
    if opt.text_prompt != "":
        prompt_list.append(opt.text_prompt)
        if opt.motion_length == 0:
            est_length = True
        else:
            length_list.append(opt.motion_length)
    elif opt.text_path != "":
        with open(opt.text_path, 'r') as f:
            lines = f.readlines()
            for line in lines:
                infos = line.split('#')
                prompt_list.append(infos[0])
                if len(infos) == 1 or (not infos[1].isdigit()):
                    est_length = True
                    length_list = []
                else:
                    length_list.append(int(infos[-1]))
    else:
        raise "A text prompt, or a file a text prompts are required!!!"
    # print('loading checkpoint {}'.format(file))

    # if est_length:
    #     print("Since no motion length are specified, we will use estimated motion lengthes!!")
    #     text_embedding = t2m_transformer.encode_text(prompt_list)
    #     pred_dis = length_estimator(text_embedding)
    #     probs = F.softmax(pred_dis, dim=-1)  # (b, ntoken)
    #     token_lens = Categorical(probs).sample()  # (b, seqlen)
        # lengths = torch.multinomial()
    


    token_lens = torch.LongTensor(length_list) // 4
    token_lens = token_lens.to(opt.device).long()

    m_length = token_lens * 4
    captions = prompt_list

    sample = 0
    kinematic_chain = t2m_kinematic_chain
    converter = Joint2BVHConvertor()
    for i in range(3):
        with torch.no_grad():
            mids = t2m_transformer.generate(captions, token_lens * 2,
                                            timesteps=opt.time_steps,
                                            cond_scale=opt.cond_scale,
                                            temperature=opt.temperature,
                                            topk_filter_thres=opt.topkr,
                                            gsample=opt.gumbel_sample)
            # print(mids)
            # print(mids.shape)
            mids = res_model.generate(mids, captions, token_lens * 2, temperature=1, cond_scale=4)
            print("mids.shape")
            print(mids.shape)
            pred_ids1 = mids[:, 0::2, :]  # 提取奇数列
            pred_ids2 = mids[:, 1::2, :]
            motionpred1 = vq_model.forward_decoder(pred_ids1)
            motionpred1 = motionpred1.detach().cpu().numpy()

            motionpred2 = vq_model.forward_decoder(pred_ids2)
            motionpred2 = motionpred2.detach().cpu().numpy()

        motionpred1 = (motionpred1 * std) + mean
        motionpred2 = (motionpred2 * std) + mean
        motionpred1 = torch.from_numpy(motionpred1).float()
        motionpred2 = torch.from_numpy(motionpred2).float()
        data = torch.cat((motionpred1, motionpred2), dim=-1)  # 在最后一个维度上连接
        data = data.numpy()

        data = data[0]
        print('data.shape')
        print(data.shape)

        motion_output = [[], []]
        motion_output[0] = data[:, :66].reshape(-1, 22, 3)
        motion_output[1] = data[:, 262:328].reshape(-1, 22, 3)

        for index, joint_data in enumerate(motion_output):
            folder_path = f"results/{captions}/npy{i}"
            # 如果文件夹不存在，则创建
            os.makedirs(folder_path, exist_ok=True)
            # 生成文件名
            filename = os.path.join(folder_path, f"person{index}.npy")
            # 保存文件
            np.save(filename, joint_data)

        motion_full = [[], []]
        motion_full[0] = data[:, :262]
        motion_full[1] = data[:, 262:524]

        for index, data in enumerate(motion_full):
            folder_path = f"results/{captions}/npy{i}"
            # 如果文件夹不存在，则创建
            os.makedirs(folder_path, exist_ok=True)
            # 生成文件名
            filename = os.path.join(folder_path, f"person_full{index}.npy")
            # 保存文件
            np.save(filename, data)


        result_folder = f"results/{captions}/npy{i}"
        os.makedirs(result_folder, exist_ok=True)


        # 生成可视化结果的路径
        result_path = os.path.join(result_folder, "vis.mp4")
        plot_t2m([motion_output[0], motion_output[1]],
                 result_path,
                 str(captions))
    


