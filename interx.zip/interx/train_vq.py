import os
from os.path import join as pjoin

import torch
from torch.utils.data import DataLoader

from models.vq.model import RVQVAE
from models.vq.vq_trainer import RVQTokenizerTrainer
from options.vq_option import arg_parse
from data.t2m_dataset import MotionDatasetV2HHI,MotionDatasetV2HHI_two
from utils import paramUtil
import numpy as np
import utils.paramUtil_hhi as paramUtil_hhi
from models.t2m_eval_wrapper import EvaluatorModelWrapper
from utils.get_opt import get_opt
from motion_loaders.dataset_motion_loader import get_dataset_motion_loader

# from utils.motion_process import recover_from_ric
# from utils.plot_script import plot_3d_motion
from utils.fixseed import fixseed

os.environ["OMP_NUM_THREADS"] = "1"




if __name__ == "__main__":
    # torch.autograd.set_detect_anomaly(True)
    opt = arg_parse(True)
    fixseed(opt.seed)

    opt.device = torch.device("cpu" if opt.gpu_id == -1 else "cuda:" + str(opt.gpu_id))
    print(f"Using Device: {opt.device}")

    opt.save_root = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.name)
    opt.model_dir = pjoin(opt.save_root, 'model')
    opt.meta_dir = pjoin(opt.save_root, 'meta')
    opt.eval_dir = pjoin(opt.save_root, 'animation')
    opt.log_dir = pjoin(opt.save_root,'./log/vq/', opt.dataset_name, opt.name)
    opt.eval_log_dir = pjoin(opt.save_root, 'eval.txt')

    os.makedirs(opt.model_dir, exist_ok=True)
    os.makedirs(opt.meta_dir, exist_ok=True)
    os.makedirs(opt.eval_dir, exist_ok=True)
    os.makedirs(opt.log_dir, exist_ok=True)
    with open(opt.eval_log_dir, 'w') as f:  # 'w'模式会创建文件
        f.write('')  # 在文件中写入空内容或其他初始化内容

    if opt.dataset_name == "hhi":
        opt.data_root = './dataset/inter-x'
        opt.motion_dir = pjoin(opt.data_root, 'motions')
        opt.text_dir = pjoin(opt.data_root, 'texts_processed')
        opt.joints_num = 56
        dim_pose = opt.joints_num * 6
        opt.max_motion_length = 150
        fps = 30
        radius = 4
        kinematic_chain = paramUtil_hhi.hhi_kinematic_chain
        dataset_opt_path = './checkpoints/hhi/Comp_v6_KLD01/opt.txt'

    else:
        raise KeyError('Dataset Does not Exists')

    wrapper_opt = get_opt(dataset_opt_path, opt.device)
    eval_wrapper = EvaluatorModelWrapper(wrapper_opt)




    net = RVQVAE(opt,
                dim_pose,
                opt.nb_code,
                opt.code_dim,
                opt.code_dim,
                opt.down_t,
                opt.stride_t,
                opt.width,
                opt.depth,
                opt.dilation_growth_rate,
                opt.vq_act,
                opt.vq_norm)

    pc_vq = sum(param.numel() for param in net.parameters())
    print(net)

    print('Total parameters of all models: {}M'.format(pc_vq/1000_000))

    trainer = RVQTokenizerTrainer(opt, vq_model=net)
    train_split_file = pjoin(opt.data_root, 'splits/train.txt')
    train_motion_file = pjoin(opt.motion_dir, 'train.h5')
    train_dataset = MotionDatasetV2HHI(opt, train_split_file, train_motion_file)
    train_loader = DataLoader(train_dataset, batch_size=opt.batch_size, drop_last=True, num_workers=4,
                              shuffle=True, pin_memory=True)
    val_split_file = pjoin(opt.data_root, 'splits/val.txt')
    val_motion_file = pjoin(opt.motion_dir, 'val.h5')
    val_dataset = MotionDatasetV2HHI(opt, val_split_file, val_motion_file)
    val_loader = DataLoader(val_dataset, batch_size=opt.batch_size, drop_last=True, num_workers=4,
                              shuffle=True, pin_memory=True)
    eval_val_loader, _ = get_dataset_motion_loader(dataset_opt_path, 32, 'val', device=opt.device)
    trainer.train(train_loader, val_loader, eval_val_loader, eval_wrapper)