import os
import torch
import numpy as np

from torch.utils.data import DataLoader
from os.path import join as pjoin

from models.mask_transformer.cross_transformer import MaskTransformer
from models.mask_transformer.transformer_trainer import MaskTransformerTrainer
from models.vq.model import RVQVAE

from options.train_option import TrainT2MOptions
import utils.paramUtil_hhi as paramUtil_hhi
# from utils.plot_script import plot_3d_motion
# from utils.motion_process import recover_from_ric
from utils.get_opt import get_opt
from utils.fixseed import fixseed
from utils.paramUtil import t2m_kinematic_chain, kit_kinematic_chain
from data.t2m_dataset import Text2MotionDatasetHHI,collate_fn
from motion_loaders.dataset_motion_loader import get_dataset_motion_loader
from models.t2m_eval_wrapper import EvaluatorModelWrapper
from utils.word_vectorizer import WordVectorizer


def load_vq_model():
    opt_path = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.vq_name, 'opt.txt')
    vq_opt = get_opt(opt_path, opt.device)
    vq_model = RVQVAE(vq_opt,
                dim_pose,
                vq_opt.nb_code,
                vq_opt.code_dim,
                vq_opt.output_emb_width,
                vq_opt.down_t,
                vq_opt.stride_t,
                vq_opt.width,
                vq_opt.depth,
                vq_opt.dilation_growth_rate,
                vq_opt.vq_act,
                vq_opt.vq_norm)
    ckpt = torch.load(pjoin(vq_opt.checkpoints_dir, vq_opt.dataset_name, vq_opt.name, 'model', 'net_best_fid.tar'),
                            map_location='cpu')
    model_key = 'vq_model' if 'vq_model' in ckpt else 'net'
    vq_model.load_state_dict(ckpt[model_key])
    print(f'Loading VQ Model {opt.vq_name}')
    return vq_model, vq_opt

if __name__ == '__main__':
    parser = TrainT2MOptions()
    opt = parser.parse()
    fixseed(opt.seed)

    opt.device = torch.device("cpu" if opt.gpu_id == -1 else "cuda:" + str(opt.gpu_id))
    torch.autograd.set_detect_anomaly(True)

    opt.save_root = pjoin(opt.checkpoints_dir, opt.dataset_name, opt.name)
    opt.model_dir = pjoin(opt.save_root, 'model')
    # opt.meta_dir = pjoin(opt.save_root, 'meta')
    opt.eval_dir = pjoin(opt.save_root, 'animation')
    opt.log_dir = pjoin(opt.save_root,'./log/t2m/', opt.dataset_name, opt.name)
    opt.eval_log_dir = pjoin(opt.save_root, 'eval.txt')

    os.makedirs(opt.model_dir, exist_ok=True)
    # os.makedirs(opt.meta_dir, exist_ok=True)
    os.makedirs(opt.eval_dir, exist_ok=True)
    os.makedirs(opt.log_dir, exist_ok=True)
    with open(opt.eval_log_dir, 'w') as f:  # 'w'模式会创建文件
        f.write('')  # 在文件中写入空内容或其他初始化内容

    if opt.dataset_name == 'hhi':
        opt.data_root = './dataset/inter-x'
        opt.motion_dir = pjoin(opt.data_root, 'motions')
        opt.joints_num = 56
        opt.max_motion_len = 150
        dim_pose = opt.joints_num * 6
        radius = 4
        fps = 30
        kinematic_chain = paramUtil_hhi.hhi_kinematic_chain
        opt.max_text_len = 35
        dataset_opt_path = './checkpoints/hhi/Comp_v6_KLD01/opt.txt'


    else:
        raise KeyError('Dataset Does Not Exist')

    opt.text_dir = pjoin(opt.data_root, 'texts_processed')

    vq_model, vq_opt = load_vq_model()

    clip_version = 'ViT-L/14@336px'

    opt.num_tokens = vq_opt.nb_code

    t2m_transformer = MaskTransformer(code_dim=vq_opt.code_dim,
                                      cond_mode='text',
                                      latent_dim=opt.latent_dim,
                                      ff_size=opt.ff_size,
                                      num_layers=opt.n_layers,
                                      num_heads=opt.n_heads,
                                      dropout=opt.dropout,
                                      clip_dim=768,
                                      cond_drop_prob=opt.cond_drop_prob,
                                      clip_version=clip_version,
                                      opt=opt)

    # if opt.fix_token_emb:
    #     t2m_transformer.load_and_freeze_token_emb(vq_model.quantizer.codebooks[0])

    all_params = 0
    pc_transformer = sum(param.numel() for param in t2m_transformer.parameters_wo_clip())

    # print(t2m_transformer)
    # print("Total parameters of t2m_transformer net: {:.2f}M".format(pc_transformer / 1000_000))
    all_params += pc_transformer

    print('Total parameters of all models: {:.2f}M'.format(all_params / 1000_000))
    w_vectorizer = WordVectorizer(pjoin(opt.data_root, 'glove'), 'hhi_vab')

    train_split_file = pjoin(opt.data_root, 'splits/train.txt')
    train_motion_file = pjoin(opt.motion_dir, 'train.h5')
    train_dataset = Text2MotionDatasetHHI(opt, train_split_file, w_vectorizer,train_motion_file)
    train_loader = DataLoader(train_dataset, batch_size=opt.batch_size, drop_last=True, num_workers=4,
                                      shuffle=True, collate_fn=collate_fn, pin_memory=True)
    val_split_file = pjoin(opt.data_root, 'splits/val.txt')
    val_motion_file = pjoin(opt.motion_dir, 'val.h5')
    val_dataset = Text2MotionDatasetHHI(opt, val_split_file,w_vectorizer, val_motion_file)
    val_loader = DataLoader(val_dataset, batch_size=opt.batch_size, drop_last=True, num_workers=4,
                                      shuffle=True, collate_fn=collate_fn, pin_memory=True)
    eval_val_loader, _ = get_dataset_motion_loader(dataset_opt_path, 32, 'val', device=opt.device)

    wrapper_opt = get_opt(dataset_opt_path, torch.device('cuda'))
    eval_wrapper = EvaluatorModelWrapper(wrapper_opt)

    trainer = MaskTransformerTrainer(opt, t2m_transformer, vq_model)

    trainer.train(train_loader, val_loader, eval_val_loader, eval_wrapper=eval_wrapper)